plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.artandpx.studio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.artandpx.studio"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "2.5-brush-eraser-icons-fix"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
