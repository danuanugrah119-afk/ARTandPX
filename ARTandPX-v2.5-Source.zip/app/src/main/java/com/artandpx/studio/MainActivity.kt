package com.artandpx.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import kotlin.math.*

data class ArtLayer(
    var name: String,
    var bitmap: Bitmap,
    var visible: Boolean = true,
    var locked: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var board: DrawingBoard
    private lateinit var status: TextView
    private val layers = mutableListOf<ArtLayer>()
    private var selectedLayer = 0
    private var pixelMode = false
    private var symmetry = 0 // 0 off, 1 vertical, 2 horizontal, 3 four-way
    private var tool = DrawingBoard.Tool.BRUSH
    private var currentColor = Color.BLACK


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,17,22)
        window.navigationBarColor = Color.rgb(16,17,22)
        layers.add(ArtLayer("Layer 1", Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888)))
        board = DrawingBoard(this, layers)
        board.setColor(currentColor)
        buildUi()
    }

    private var toolbarOpen = true
    private lateinit var toolbarPanel: LinearLayout
    private lateinit var modeButton: Button

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16,17,22))
            setPadding(8, 6, 8, 6)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "ARTandPX"; textSize = 19f; setTextColor(Color.WHITE); setPadding(6, 8, 6, 8)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("⌃  TOOLS") { toolbarOpen = !toolbarOpen; toolbarPanel.visibility = if (toolbarOpen) View.VISIBLE else View.GONE })
        root.addView(header)

        val modes = makeRow(
            button("✎  ART BIASA") { pixelMode = false; board.setPixelMode(false); refreshStatus(); updateModeLabel() },
            button("▦  PIXEL ART") { pixelMode = true; board.setPixelMode(true); refreshStatus(); updateModeLabel() }
        )
        root.addView(modes)
        status = TextView(this).apply {
            text = "ART BIASA • 1 layer"; textSize = 12f
            setTextColor(Color.LTGRAY); setPadding(5, 5, 5, 7)
        }
        root.addView(status)

        toolbarPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        toolbarPanel.addView(makeRow(
            iconButton("Brush", "brush") { setTool(DrawingBoard.Tool.BRUSH) },
            iconButton("Eraser", "eraser") { setTool(DrawingBoard.Tool.ERASER) },
            iconButton("Line", "line") { setTool(DrawingBoard.Tool.LINE) },
            iconButton("Rectangle", "rect") { setTool(DrawingBoard.Tool.RECT) },
            iconButton("Oval", "oval") { setTool(DrawingBoard.Tool.OVAL) }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Color", "color") { chooseColor() },
            iconButton("Brush size", "size") { chooseBrushSize() },
            iconButton("Canvas", "canvas") { chooseCanvasSize() },
            iconButton("Mirror", "mirror") { chooseSymmetry() },
            iconButton("Layers", "layers") { showLayers() },
            iconButton("Undo", "undo") { board.undo() },
            iconButton("Redo", "redo") { board.redo() }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Import", "import") {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
                startActivityForResult(intent, 410)
            },
            iconButton("Export", "export") { exportPng() },
            iconButton("Clear", "clear") { confirmClear() }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Zoom +", "zoom_in") { board.zoomBy(1.25f) },
            iconButton("Zoom −", "zoom_out") { board.zoomBy(0.8f) },
            iconButton("Reset", "reset") { board.resetView() }
        ))
        root.addView(toolbarPanel)

        val canvasFrame = FrameLayout(this).apply { setBackgroundColor(Color.rgb(37,38,45)) }
        canvasFrame.addView(board, FrameLayout.LayoutParams(-1, -1))
        root.addView(canvasFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val palette = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 4) }
        val colors = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW,
            Color.CYAN, Color.MAGENTA, Color.rgb(255,128,0), Color.rgb(128,80,220))
        colors.forEach { c ->
            val swatch = View(this).apply {
                setBackgroundColor(c)
                setOnClickListener { currentColor = c; board.setColor(c); refreshStatus() }
            }
            palette.addView(swatch, LinearLayout.LayoutParams(0, 32, 1f).apply { setMargins(3, 0, 3, 0) })
        }
        root.addView(palette)
        setContentView(root)
        refreshStatus()
    }

    private fun updateModeLabel() { refreshStatus() }

    private fun buildUiRefresh() {
        // Refresh labels while preserving the existing drawing board.
        status.text = "${if (pixelMode) "PIXEL ART • white 8px grid" else "ART BIASA • smooth brush"} • ${layers.size} layer • ${board.canvasSize}×${board.canvasSize} • ${symmetryName()}"
    }

    private fun makeRow(vararg views: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 3, 0, 3)
            views.forEach { addView(it, LinearLayout.LayoutParams(0, (resources.displayMetrics.density * 62).toInt(), 1f).apply {
                setMargins(2, 0, 2, 0)
            }) }
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48,49,61))
            setOnClickListener { action() }
        }

    private fun iconButton(label: String, kind: String, action: () -> Unit): Button {
        val size = (resources.displayMetrics.density * 24).toInt().coerceAtLeast(24)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = size * .09f
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val f = size.toFloat(); val mid = f / 2f
        when (kind) {
            "brush" -> { c.drawLine(f*.22f,f*.78f,f*.72f,f*.28f,p); c.drawLine(f*.62f,f*.18f,f*.82f,f*.38f,p); c.drawOval(f*.12f,f*.68f,f*.35f,f*.9f,p) }
            "eraser" -> { val path=Path().apply { moveTo(f*.25f,f*.65f); lineTo(f*.55f,f*.2f); lineTo(f*.86f,f*.5f); lineTo(f*.56f,f*.85f); close() }; c.drawPath(path,p); c.drawLine(f*.43f,f*.72f,f*.7f,f*.72f,p) }
            "line" -> c.drawLine(f*.18f,f*.82f,f*.82f,f*.18f,p)
            "rect" -> c.drawRect(f*.18f,f*.2f,f*.82f,f*.8f,p)
            "oval" -> c.drawOval(f*.16f,f*.25f,f*.84f,f*.75f,p)
            "color" -> { c.drawCircle(mid,mid,f*.3f,p); c.drawCircle(mid,mid,f*.1f,p) }
            "size" -> { c.drawLine(f*.18f,f*.5f,f*.82f,f*.5f,p); c.drawCircle(f*.5f,f*.5f,f*.2f,p) }
            "canvas" -> { c.drawRect(f*.18f,f*.18f,f*.82f,f*.82f,p); c.drawLine(f*.18f,f*.4f,f*.82f,f*.4f,p) }
            "mirror" -> { c.drawLine(mid,f*.15f,mid,f*.85f,p); c.drawLine(f*.12f,f*.5f,f*.42f,f*.25f,p); c.drawLine(f*.12f,f*.5f,f*.42f,f*.75f,p); c.drawLine(f*.88f,f*.5f,f*.58f,f*.25f,p); c.drawLine(f*.88f,f*.5f,f*.58f,f*.75f,p) }
            "layers" -> { c.drawLine(f*.5f,f*.15f,f*.88f,f*.38f,p); c.drawLine(f*.88f,f*.38f,f*.5f,f*.6f,p); c.drawLine(f*.5f,f*.6f,f*.12f,f*.38f,p); c.drawLine(f*.12f,f*.38f,f*.5f,f*.15f,p); c.drawLine(f*.18f,f*.58f,f*.5f,f*.78f,p); c.drawLine(f*.5f,f*.78f,f*.82f,f*.58f,p) }
            "undo" -> { c.drawArc(f*.25f,f*.25f,f*.82f,f*.82f,200f,230f,false,p); c.drawLine(f*.15f,f*.25f,f*.15f,f*.52f,p); c.drawLine(f*.15f,f*.25f,f*.42f,f*.25f,p) }
            "redo" -> { c.drawArc(f*.18f,f*.25f,f*.75f,f*.82f,110f,230f,false,p); c.drawLine(f*.85f,f*.25f,f*.85f,f*.52f,p); c.drawLine(f*.85f,f*.25f,f*.58f,f*.25f,p) }
            "import" -> { c.drawRect(f*.15f,f*.38f,f*.85f,f*.82f,p); c.drawLine(mid,f*.12f,mid,f*.58f,p); c.drawLine(f*.32f,f*.32f,mid,f*.12f,p); c.drawLine(f*.68f,f*.32f,mid,f*.12f,p) }
            "export" -> { c.drawRect(f*.15f,f*.48f,f*.85f,f*.85f,p); c.drawLine(mid,f*.12f,mid,f*.62f,p); c.drawLine(f*.32f,f*.42f,mid,f*.62f,p); c.drawLine(f*.68f,f*.42f,mid,f*.62f,p) }
            "clear" -> { c.drawRect(f*.25f,f*.3f,f*.75f,f*.82f,p); c.drawLine(f*.18f,f*.22f,f*.82f,f*.22f,p) }
            "zoom_in" -> { c.drawCircle(f*.42f,f*.42f,f*.25f,p); c.drawLine(f*.6f,f*.6f,f*.85f,f*.85f,p); c.drawLine(f*.42f,f*.3f,f*.42f,f*.54f,p); c.drawLine(f*.3f,f*.42f,f*.54f,f*.42f,p) }
            "zoom_out" -> { c.drawCircle(f*.42f,f*.42f,f*.25f,p); c.drawLine(f*.6f,f*.6f,f*.85f,f*.85f,p); c.drawLine(f*.3f,f*.42f,f*.54f,f*.42f,p) }
            else -> c.drawCircle(mid,mid,f*.28f,p)
        }
        val drawable = BitmapDrawable(resources, bmp).apply { setBounds(0,0,size,size) }
        return Button(this).apply {
            text = label; textSize = 9f; isAllCaps = false; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(48,49,61))
            setCompoundDrawables(null, drawable, null, null); compoundDrawablePadding = 1
            setPadding(1,2,1,2); setOnClickListener { action() }
        }
    }

    private fun setTool(t: DrawingBoard.Tool) {
        tool = t; board.setTool(t)
        Toast.makeText(this, "${t.name.lowercase()} tool", Toast.LENGTH_SHORT).show()
    }

    private fun chooseSymmetry() {
        val options = arrayOf("Off", "Vertical mirror", "Horizontal mirror", "Four-way")
        AlertDialog.Builder(this).setTitle("Symmetry")
            .setSingleChoiceItems(options, symmetry) { d, which ->
                symmetry = which; board.setSymmetry(which); d.dismiss(); refreshStatus()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun symmetryName() = arrayOf("Mirror off", "Vertical", "Horizontal", "Four-way")[symmetry]

    private fun chooseColor() {
        val wheel = ColorWheelView(this).apply { setColor(currentColor) }
        val hex = EditText(this).apply {
            hint = "#RRGGBB"; setSingleLine(true)
            setText(String.format("#%06X", 0xFFFFFF and currentColor))
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 4)
            addView(wheel, LinearLayout.LayoutParams(-1, 240))
            addView(hex)
        }
        val dialog = AlertDialog.Builder(this).setTitle("Roda warna & kode HEX")
            .setView(wrap)
            .setPositiveButton("Pakai warna", null)
            .setNegativeButton("Batal", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                try {
                    currentColor = if (hex.text.isNullOrBlank()) wheel.selectedColor
                        else Color.parseColor(if (hex.text.toString().trim().startsWith("#")) hex.text.toString().trim() else "#" + hex.text.toString().trim())
                    board.setColor(currentColor); refreshStatus(); dialog.dismiss()
                } catch (_: Exception) {
                    hex.error = "Gunakan format #RRGGBB, contoh #FF8800"
                }
            }
        }
        wheel.onColorChanged = { c -> hex.setText(String.format("#%06X", 0xFFFFFF and c)) }
        dialog.show()
    }

    private fun chooseBrushSize() {
        val seek = SeekBar(this).apply { max = 199; progress = 7 }
        val value = TextView(this).apply { text = "Ukuran kuas: 8 px"; setPadding(12, 8, 12, 8) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                val size = p + 1; value.text = "Ukuran kuas: $size px"; board.setBrushSize(size.toFloat())
            }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 4); addView(value); addView(seek) }.also { box ->
            AlertDialog.Builder(this).setTitle("Ukuran kuas (1–200 px)").setView(box).setPositiveButton("Selesai", null).show()
        }
    }

    private fun chooseCanvasSize() {
        val sizes = arrayOf("128 × 128", "256 × 256", "512 × 512", "1024 × 1024", "2048 × 2048")
        val values = intArrayOf(128, 256, 512, 1024, 2048)
        AlertDialog.Builder(this).setTitle("Ukuran kanvas")
            .setItems(sizes) { _, which ->
                board.resizeCanvas(values[which])
                refreshStatus()
                Toast.makeText(this, "Kanvas ${values[which]} × ${values[which]} px", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun showLayers() {
        val names = layers.mapIndexed { i, l ->
            "${if (i == selectedLayer) "▶ " else ""}${if (l.visible) "◉" else "○"}${if (l.locked) " 🔒 " else "  "}${l.name}"
        }.toMutableList()
        names.add("＋ Add new layer")
        AlertDialog.Builder(this).setTitle("Layers")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == layers.size) {
                    layers.add(ArtLayer("Layer ${layers.size + 1}", Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)))
                    selectedLayer = layers.lastIndex
                    board.setLayers(layers, selectedLayer)
                    showLayerActions(selectedLayer)
                } else {
                    selectedLayer = which
                    board.setLayers(layers, selectedLayer)
                    showLayerActions(which)
                }
                refreshStatus()
            }.setNegativeButton("Close", null).show()
    }

    private fun showLayerActions(index: Int) {
        val layer = layers[index]
        val actions = arrayOf(
            "Rename", if (layer.visible) "Hide layer" else "Show layer",
            if (layer.locked) "Unlock layer" else "Lock layer", "Delete layer"
        )
        AlertDialog.Builder(this).setTitle(layer.name).setItems(actions) { _, choice ->
            when (choice) {
                0 -> {
                    val edit = EditText(this).apply { setText(layer.name) }
                    AlertDialog.Builder(this).setTitle("Rename layer").setView(edit)
                        .setPositiveButton("Save") { _, _ ->
                            layer.name = edit.text.toString().ifBlank { layer.name }
                            showLayers()
                        }.setNegativeButton("Cancel", null).show()
                }
                1 -> { layer.visible = !layer.visible; board.invalidate(); showLayers() }
                2 -> { layer.locked = !layer.locked; showLayers() }
                3 -> if (layers.size > 1) {
                    layers.removeAt(index); selectedLayer = (selectedLayer - 1).coerceAtLeast(0)
                    board.setLayers(layers, selectedLayer); showLayers()
                } else Toast.makeText(this, "Minimal harus ada satu layer", Toast.LENGTH_SHORT).show()
            }
        }.setNegativeButton("Back") { _, _ -> showLayers() }.show()
    }

    @Deprecated("Legacy activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 410 && resultCode == RESULT_OK) data?.data?.let { addImportedLayer(it) }
    }

    private fun addImportedLayer(uri: Uri) {
        try {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw Exception("Gambar tidak terbaca")
            val target = Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)
            val c = Canvas(target)
            val scale = min(board.canvasSize.toFloat() / bmp.width, board.canvasSize.toFloat() / bmp.height)
            val w = bmp.width * scale; val h = bmp.height * scale
            val dst = RectF((board.canvasSize-w)/2, (board.canvasSize-h)/2,
                (board.canvasSize+w)/2, (board.canvasSize+h)/2)
            c.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            layers.add(ArtLayer("Imported ${layers.size}", target))
            selectedLayer = layers.lastIndex
            board.setLayers(layers, selectedLayer)
            Toast.makeText(this, "Gambar masuk sebagai layer baru", Toast.LENGTH_SHORT).show()
            refreshStatus()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal import: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportPng() {
        try {
            val merged = Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)
            val c = Canvas(merged)
            layers.filter { it.visible }.forEach { c.drawBitmap(it.bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG)) }
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ARTandPX_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ARTandPX")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Tidak bisa membuat file")
            contentResolver.openOutputStream(uri)?.use { merged.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "PNG tersimpan di Pictures/ARTandPX", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setMessage("Hapus isi layer aktif?")
            .setPositiveButton("Hapus") { _, _ -> board.clearCurrent() }
            .setNegativeButton("Batal", null).show()
    }

    private fun refreshStatus() {
        status.text = "${if (pixelMode) "PIXEL ART • white 8px grid" else "ART BIASA • smooth brush"} • ${layers.size} layer • ${board.canvasSize}×${board.canvasSize} • ${symmetryName()}"
    }
}

class ColorWheelView(context: android.content.Context) : View(context) {
    var selectedColor: Int = Color.RED
        private set
    var onColorChanged: ((Int) -> Unit)? = null
    private val wheelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE }
    private var cx = 0f; private var cy = 0f; private var radius = 0f
    private val colors = IntArray(361) { i -> Color.HSVToColor(floatArrayOf(i.toFloat(), 1f, 1f)) }
    fun setColor(c: Int) { selectedColor = c; invalidate() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        cx = width / 2f; cy = height / 2f; radius = min(width, height) * .43f
        for (i in 0 until 360) {
            wheelPaint.color = colors[i]
            canvas.drawArc(cx-radius, cy-radius, cx+radius, cy+radius, i.toFloat(), 1.2f, true, wheelPaint)
        }
        val hsv = FloatArray(3); Color.colorToHSV(selectedColor, hsv)
        val a = Math.toRadians(hsv[0].toDouble())
        val r = radius * hsv[1]
        val x = cx + cos(a).toFloat()*r; val y = cy + sin(a).toFloat()*r
        canvas.drawCircle(x, y, 10f, markerPaint)
    }
    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            val dx = event.x-cx; val dy = event.y-cy
            val hue = ((Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())) + 360.0) % 360.0).toFloat()
            val sat = (sqrt(dx*dx+dy*dy)/radius).coerceIn(0f, 1f)
            selectedColor = Color.HSVToColor(floatArrayOf(hue, sat, 1f))
            onColorChanged?.invoke(selectedColor); invalidate(); return true
        }
        return true
    }
}

class DrawingBoard(context: android.content.Context, initialLayers: MutableList<ArtLayer>) : View(context) {
    enum class Tool { BRUSH, ERASER, LINE, RECT, OVAL }
    var canvasSize = 1024
        private set
    private var layers = initialLayers
    private var selected = 0
    private var color = Color.BLACK
    private var tool = Tool.BRUSH
    private var pixelMode = false
    private var symmetry = 0
    private var brushSize = 8f
    private var downX = 0f; private var downY = 0f
    private var lastX = 0f; private var lastY = 0f
    private var drawing = false
    private var scale = 1f
    private var offsetX = 0f; private var offsetY = 0f
    private val undo = ArrayDeque<Bitmap>()
    private val redo = ArrayDeque<Bitmap>()
    private var beforeStroke: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = this@DrawingBoard.color; strokeWidth = brushSize
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        style = Paint.Style.STROKE
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(205, 205, 205); style = Paint.Style.STROKE; strokeWidth = 1f
    }
    private val bgPaint = Paint().apply { color = Color.WHITE }
    private var previewX = 0f
    private var previewY = 0f
    private var showPreview = false
    private var pinchStartDistance = 0f
    private var pinchStartScale = 1f
    private var lastMidX = 0f
    private var lastMidY = 0f

    fun setColor(c: Int) { color = c; invalidate() }
    fun setBrushSize(size: Float) { brushSize = size.coerceIn(1f, 200f) }
    fun resizeCanvas(size: Int) {
        if (size == canvasSize) return
        layers.forEach { layer ->
            val scaled = Bitmap.createScaledBitmap(layer.bitmap, size, size, !pixelMode)
            layer.bitmap = scaled
        }
        canvasSize = size; undo.clear(); redo.clear(); invalidate()
    }
    fun setTool(t: Tool) { tool = t }
    fun setPixelMode(enabled: Boolean) {
        // Keep the document resolution unchanged; pixel mode snaps strokes to a coarse grid.
        pixelMode = enabled
        invalidate()
    }
    fun setSymmetry(mode: Int) { symmetry = mode; invalidate() }
    fun setLayers(newLayers: MutableList<ArtLayer>, index: Int) {
        layers = newLayers; selected = index.coerceIn(0, layers.lastIndex); invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val side = min(width, height) * 0.92f
        val left = (width-side)/2f; val top = (height-side)/2f
        val save = canvas.save()
        canvas.translate(left + offsetX, top + offsetY)
        canvas.scale(scale * side / canvasSize, scale * side / canvasSize)
        canvas.drawRect(0f, 0f, canvasSize.toFloat(), canvasSize.toFloat(), bgPaint)
        layers.filter { it.visible }.forEach { canvas.drawBitmap(it.bitmap, 0f, 0f, Paint(if (pixelMode) 0 else Paint.FILTER_BITMAP_FLAG)) }
        // Pixel mode uses a clean white canvas with thin, evenly spaced grid lines.
        if (pixelMode) {
            val grid = 8
            for (v in 0..canvasSize step grid) {
                canvas.drawLine(v.toFloat(), 0f, v.toFloat(), canvasSize.toFloat(), gridPaint)
                canvas.drawLine(0f, v.toFloat(), canvasSize.toFloat(), v.toFloat(), gridPaint)
            }
        }
        // Live outline preview while dragging shape tools.
        if (showPreview && tool in listOf(Tool.LINE, Tool.RECT, Tool.OVAL)) {
            val px = if (pixelMode) snap(previewX) else previewX
            val py = if (pixelMode) snap(previewY) else previewY
            val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = this@DrawingBoard.color; alpha = 190; style = Paint.Style.STROKE
                strokeWidth = if (pixelMode) max(8f, (brushSize / 8f).roundToInt() * 8f) else brushSize
                pathEffect = DashPathEffect(floatArrayOf(10f, 7f), 0f)
            }
            val l=min(downX,px); val r=max(downX,px); val t=min(downY,py); val b=max(downY,py)
            when (tool) {
                Tool.LINE -> canvas.drawLine(downX, downY, px, py, previewPaint)
                Tool.RECT -> canvas.drawRect(l,t,r,b,previewPaint)
                Tool.OVAL -> canvas.drawOval(l,t,r,b,previewPaint)
                else -> Unit
            }
        }
        canvas.restoreToCount(save)
    }

    private fun toCanvas(x: Float, y: Float): PointF {
        val side = min(width, height) * 0.92f
        val left = (width-side)/2f + offsetX
        val top = (height-side)/2f + offsetY
        val factor = scale * side / canvasSize
        return PointF(((x-left)/factor).coerceIn(0f, canvasSize.toFloat()),
            ((y-top)/factor).coerceIn(0f, canvasSize.toFloat()))
    }

    fun zoomBy(factor: Float) { scale = (scale * factor).coerceIn(0.25f, 8f); invalidate() }
    fun resetView() { scale = 1f; offsetX = 0f; offsetY = 0f; invalidate() }
    private fun distance(e: MotionEvent): Float {
        val dx=e.getX(0)-e.getX(1); val dy=e.getY(0)-e.getY(1); return hypot(dx,dy)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> if (event.pointerCount >= 2) {
                drawing = false; showPreview = false
                pinchStartDistance = distance(event).coerceAtLeast(1f); pinchStartScale = scale
                lastMidX = (event.getX(0)+event.getX(1))/2f
                lastMidY = (event.getY(0)+event.getY(1))/2f
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> if (event.pointerCount >= 2) {
                val d=distance(event).coerceAtLeast(1f)
                scale=(pinchStartScale*d/pinchStartDistance).coerceIn(0.25f,8f)
                val mx=(event.getX(0)+event.getX(1))/2f; val my=(event.getY(0)+event.getY(1))/2f
                offsetX += mx-lastMidX; offsetY += my-lastMidY
                lastMidX=mx; lastMidY=my; invalidate(); return true
            }
            MotionEvent.ACTION_DOWN -> {
                val p = toCanvas(event.x, event.y)
                downX = if (pixelMode) snap(p.x) else p.x
                downY = if (pixelMode) snap(p.y) else p.y
                lastX = downX; lastY = downY; previewX=downX; previewY=downY
                drawing = true; showPreview = tool in listOf(Tool.LINE, Tool.RECT, Tool.OVAL)
                val layer = layers.getOrNull(selected) ?: return true
                if (layer.locked) { drawing = false; showPreview=false; return true }
                beforeStroke = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true)
                if (tool == Tool.BRUSH || tool == Tool.ERASER) {
                    drawSegment(downX, downY, downX, downY)
                }
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> if (drawing && event.pointerCount == 1) {
                val p = toCanvas(event.x, event.y)
                val x=if(pixelMode) snap(p.x) else p.x; val y=if(pixelMode) snap(p.y) else p.y
                if (tool == Tool.BRUSH || tool == Tool.ERASER) {
                    drawSegment(lastX, lastY, x, y); lastX=x; lastY=y
                } else { previewX=x; previewY=y }
                invalidate(); return true
            }
            MotionEvent.ACTION_UP -> if (drawing) {
                val p = toCanvas(event.x, event.y)
                val x=if(pixelMode) snap(p.x) else p.x; val y=if(pixelMode) snap(p.y) else p.y
                when (tool) {
                    Tool.LINE -> drawShape(downX, downY, x, y, Tool.LINE)
                    Tool.RECT -> drawShape(downX, downY, x, y, Tool.RECT)
                    Tool.OVAL -> drawShape(downX, downY, x, y, Tool.OVAL)
                    else -> if (downX == x && downY == y && tool == Tool.BRUSH || downX == x && downY == y && tool == Tool.ERASER) drawSegment(downX, downY, x, y)
                }
                beforeStroke?.let { undo.addLast(it); while (undo.size > 20) undo.removeFirst() }
                redo.clear(); beforeStroke = null; drawing = false; showPreview=false
                invalidate(); return true
            }
            MotionEvent.ACTION_CANCEL -> { drawing=false; showPreview=false; beforeStroke=null; invalidate(); return true }
        }
        return true
    }

    private fun snap(v: Float): Float = if (pixelMode) ((v / 8f).roundToInt().coerceIn(0, canvasSize / 8 - 1) * 8 + 4).toFloat() else v

    private fun drawSegment(x1: Float, y1: Float, x2: Float, y2: Float) {
        val layer = layers.getOrNull(selected) ?: return
        val c = Canvas(layer.bitmap)
        val p = Paint(if (pixelMode) 0 else Paint.ANTI_ALIAS_FLAG).apply {
            color = if (tool == Tool.ERASER) Color.TRANSPARENT else this@DrawingBoard.color
            strokeWidth = if (pixelMode) max(8f, (brushSize / 8f).roundToInt() * 8f) else brushSize
            strokeCap = if (pixelMode) Paint.Cap.SQUARE else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND; style = Paint.Style.STROKE
            xfermode = if (tool == Tool.ERASER) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
        }
        val points = mutableListOf(PointF(x2,y2))
        if (symmetry == 1 || symmetry == 3) points.add(PointF(canvasSize-x2, y2))
        if (symmetry == 2 || symmetry == 3) points.add(PointF(x2, canvasSize-y2))
        if (symmetry == 3) points.add(PointF(canvasSize-x2, canvasSize-y2))
        points.forEach { q ->
            val mirrorStartX = if (q.x == canvasSize-x2) canvasSize-x1 else x1
            val mirrorStartY = if (q.y == canvasSize-y2) canvasSize-y1 else y1
            val a = snap(mirrorStartX); val b = snap(mirrorStartY)
            val d = snap(q.x); val e = snap(q.y)
            if (abs(d-a) < 0.01f && abs(e-b) < 0.01f) {
                val stamp = Paint(p).apply { style = Paint.Style.FILL }
                c.drawCircle(a, b, max(brushSize / 2f, if (pixelMode) 4f else 0.5f), stamp)
            } else c.drawLine(a,b,d,e,p)
        }
    }

    private fun drawShape(x1: Float, y1: Float, x2: Float, y2: Float, shape: Tool) {
        val layer = layers.getOrNull(selected) ?: return
        val p = Paint(if (pixelMode) 0 else Paint.ANTI_ALIAS_FLAG).apply {
            color = this@DrawingBoard.color; strokeWidth = if (pixelMode) max(8f, (brushSize / 8f).roundToInt() * 8f) else brushSize; style = Paint.Style.STROKE
        }
        val c = Canvas(layer.bitmap)
        fun one(a: Float, b: Float, d: Float, e: Float) {
            val l=min(a,d); val r=max(a,d); val t=min(b,e); val bot=max(b,e)
            when(shape) {
                Tool.LINE -> c.drawLine(a,b,d,e,p)
                Tool.RECT -> c.drawRect(l,t,r,bot,p)
                Tool.OVAL -> c.drawOval(l,t,r,bot,p)
                else -> {}
            }
        }
        one(x1,y1,x2,y2)
        if (symmetry == 1 || symmetry == 3) one(canvasSize-x1,y1,canvasSize-x2,y2)
        if (symmetry == 2 || symmetry == 3) one(x1,canvasSize-y1,x2,canvasSize-y2)
        if (symmetry == 3) one(canvasSize-x1,canvasSize-y1,canvasSize-x2,canvasSize-y2)
    }

    fun undo() {
        if (undo.isEmpty()) return
        val layer = layers[selected]
        redo.addLast(layer.bitmap.copy(Bitmap.Config.ARGB_8888, true))
        val previous = undo.removeLast()
        Canvas(layer.bitmap).drawBitmap(previous, 0f, 0f, Paint())
        invalidate()
    }
    fun redo() {
        if (redo.isEmpty()) return
        val layer = layers[selected]
        undo.addLast(layer.bitmap.copy(Bitmap.Config.ARGB_8888, true))
        val next = redo.removeLast()
        Canvas(layer.bitmap).drawBitmap(next, 0f, 0f, Paint())
        invalidate()
    }
    fun clearCurrent() {
        val layer = layers[selected]
        if (layer.locked) return
        undo.addLast(layer.bitmap.copy(Bitmap.Config.ARGB_8888, true))
        Canvas(layer.bitmap).drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        invalidate()
    }
}
