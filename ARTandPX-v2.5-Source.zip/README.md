# ARTandPX 2.5 – Brush, Eraser & Icon Fix

This update focuses on core drawing reliability and visible vector-style toolbar icons.

- Brush and eraser stamp immediately on touch-down, then draw continuous strokes while moving.
- Eraser uses PorterDuff CLEAR to remove alpha from the active layer rather than painting white.
- Tool buttons now show custom-drawn icons with labels for brush, eraser, line, rectangle, oval, color, size, canvas, mirror, layers, undo, redo, import, export, clear and zoom.
- Shape tools retain live previews and commit on release.
- Existing Art/Pixel modes, grid, zoom/pan, layers, symmetry, color, import/export and canvas controls are retained.

Build with JDK 17 and Gradle 8.9 using the included GitHub Actions workflow. Device testing is still required.
