package com.artandpx.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.Stack
import kotlin.math.*

data class ArtLayer(
    var name: String,
    var bitmap: Bitmap,
    var visible: Boolean = true,
    var locked: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var board: DrawingBoard
    private lateinit var status: TextView
    private val layers = mutableListOf<ArtLayer>()
    private var selectedLayer = 0
    private var pixelMode = false
    private var symmetry = 0 // 0: off, 1: vertical, 2: horizontal, 3: four-way
    private var tool = DrawingBoard.Tool.BRUSH
    private var currentColor = Color.BLACK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 17, 22)
        window.navigationBarColor = Color.rgb(16, 17, 22)
        // Default Webtoon panel (800x1280 px)
        layers.add(ArtLayer("Layer 1", Bitmap.createBitmap(800, 1280, Bitmap.Config.ARGB_8888)))
        board = DrawingBoard(this, layers)
        board.setColor(currentColor)
        buildUi()
    }

    private var toolbarOpen = true
    private lateinit var toolbarPanel: LinearLayout

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 17, 22))
            setPadding(8, 4, 8, 4)
        }

        // Top Header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "ARTandPX Beta v0.5"; textSize = 18f; setTextColor(Color.WHITE); setPadding(6, 4, 6, 4)
            setTypeface(null, Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("⌃ TOOLS") { toolbarOpen = !toolbarOpen; toolbarPanel.visibility = if (toolbarOpen) View.VISIBLE else View.GONE })
        root.addView(header)

        // Mode switch row
        val modes = makeRow(
            button("✎ ART BIASA") { pixelMode = false; board.setPixelMode(false); refreshStatus() },
            button("▦ PIXEL ART v0.5") { pixelMode = true; board.setPixelMode(true); refreshStatus() }
        )
        root.addView(modes)

        status = TextView(this).apply {
            text = "ARTandPX Beta v0.5 • Webtoon & Drawing Studio"; textSize = 11f
            setTextColor(Color.LTGRAY); setPadding(4, 2, 4, 4)
        }
        root.addView(status)

        // Clean Organized Toolbar Container (Tabbed/Category Layout)
        toolbarPanel = LinearLayout(this).apply { 
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(22, 24, 32))
            setPadding(4, 4, 4, 4)
        }

        // Category 1: Drawing & Creative Tools (Includes Brush, Eraser, Text, Shapes)
        toolbarPanel.addView(sectionHeader("TOOLS GAMBAR, TEKS & BENTUK"))
        toolbarPanel.addView(makeRow(
            iconButton("Brush", "brush") { setTool(DrawingBoard.Tool.BRUSH) },
            iconButton("Eraser", "eraser") { setTool(DrawingBoard.Tool.ERASER) },
            iconButton("Text", "text") { promptAddText() },
            iconButton("Line", "line") { setTool(DrawingBoard.Tool.LINE) },
            iconButton("Rect", "rect") { setTool(DrawingBoard.Tool.RECT) },
            iconButton("Oval", "oval") { setTool(DrawingBoard.Tool.OVAL) }
        ))

        // Category 2: Canvas, Crop, Color & Symmetry
        toolbarPanel.addView(sectionHeader("PENGATURAN KANVAS, CROP & WARNA"))
        toolbarPanel.addView(makeRow(
            iconButton("Color", "color") { chooseColor() },
            iconButton("Size", "size") { chooseBrushSize() },
            iconButton("Canvas", "canvas") { chooseCanvasSize() },
            iconButton("Crop", "crop") { showCropDialog() },
            iconButton("Mirror", "mirror") { chooseSymmetry() },
            iconButton("Layers", "layers") { showLayers() }
        ))

        // Category 3: History & View Actions
        toolbarPanel.addView(sectionHeader("AKSI, ZOOM & FILE"))
        toolbarPanel.addView(makeRow(
            iconButton("Undo", "undo") { board.undo() },
            iconButton("Redo", "redo") { board.redo() },
            iconButton("Zoom+", "zoom_in") { board.zoomBy(1.25f) },
            iconButton("Zoom-", "zoom_out") { board.zoomBy(0.8f) },
            iconButton("Reset", "reset") { board.resetView() }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Import", "import") {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
                startActivityForResult(intent, 410)
            },
            iconButton("Export", "export") { showExportDialog() },
            iconButton("Clear", "clear") { confirmClear() }
        ))

        root.addView(toolbarPanel)

        // Drawing Canvas Frame
        val canvasFrame = FrameLayout(this).apply { setBackgroundColor(Color.rgb(37, 38, 45)) }
        canvasFrame.addView(board, FrameLayout.LayoutParams(-1, -1))
        root.addView(canvasFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        // Quick Color Palette
        val palette = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 2) }
        val colors = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW,
            Color.CYAN, Color.MAGENTA, Color.rgb(255, 128, 0), Color.rgb(128, 80, 220))
        colors.forEach { c ->
            val swatch = View(this).apply {
                setBackgroundColor(c)
                setOnClickListener { currentColor = c; board.setColor(c); refreshStatus() }
            }
            palette.addView(swatch, LinearLayout.LayoutParams(0, 30, 1f).apply { setMargins(2, 0, 2, 0) })
        }
        root.addView(palette)
        setContentView(root)
        refreshStatus()
    }

    private fun sectionHeader(title: String): TextView {
        return TextView(this).apply {
            text = "— $title —"
            textSize = 9.5f
            setTextColor(Color.parseColor("#8E92A4"))
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 2)
            setTypeface(null, Typeface.BOLD)
        }
    }

    private fun makeRow(vararg views: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 2, 0, 2)
            views.forEach { addView(it, LinearLayout.LayoutParams(0, (resources.displayMetrics.density * 54).toInt(), 1f).apply {
                setMargins(2, 0, 2, 0)
            }) }
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48, 49, 61))
            setOnClickListener { action() }
        }

    private fun iconButton(label: String, kind: String, action: () -> Unit): Button {
        val size = (resources.displayMetrics.density * 22).toInt().coerceAtLeast(20)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = size * .09f
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val f = size.toFloat(); val mid = f / 2f
        when (kind) {
            "brush" -> { c.drawLine(f*.22f,f*.78f,f*.72f,f*.28f,p); c.drawLine(f*.62f,f*.18f,f*.82f,f*.38f,p); c.drawOval(f*.12f,f*.68f,f*.35f,f*.9f,p) }
            "eraser" -> { val path = Path().apply { moveTo(f*.25f,f*.65f); lineTo(f*.55f,f*.2f); lineTo(f*.86f,f*.5f); lineTo(f*.56f,f*.85f); close() }; c.drawPath(path,p); c.drawLine(f*.43f,f*.72f,f*.7f,f*.72f,p) }
            "text" -> { c.drawRect(f*.15f,f*.2f,f*.85f,f*.8f,p); c.drawLine(f*.35f,f*.4f,f*.65f,f*.4f,p); c.drawLine(mid,f*.4f,mid,f*.75f,p) }
            "crop" -> { c.drawRect(f*.2f,f*.2f,f*.75f,f*.75f,p); c.drawLine(f*.75f,f*.75f,f*.85f,f*.85f,p); c.drawLine(f*.2f,f*.75f,f*.1f,f*.85f,p); c.drawLine(f*.75f,f*.2f,f*.85f,f*.1f,p) }
            "line" -> c.drawLine(f*.18f,f*.82f,f*.82f,f*.18f,p)
            "rect" -> c.drawRect(f*.18f,f*.2f,f*.82f,f*.8f,p)
            "oval" -> c.drawOval(f*.16f,f*.25f,f*.84f,f*.75f,p)
            "color" -> { c.drawCircle(mid,mid,f*.3f,p); c.drawCircle(mid,mid,f*.1f,p) }
            "size" -> { c.drawLine(f*.18f,f*.5f,f*.82f,f*.5f,p); c.drawCircle(f*.5f,f*.5f,f*.2f,p) }
            "canvas" -> { c.drawRect(f*.18f,f*.18f,f*.82f,f*.82f,p); c.drawLine(f*.18f,f*.4f,f*.82f,f*.4f,p) }
            "mirror" -> { c.drawLine(mid,f*.15f,mid,f*.85f,p); c.drawLine(f*.12f,f*.5f,f*.42f,f*.25f,p); c.drawLine(f*.12f,f*.5f,f*.42f,f*.75f,p); c.drawLine(f*.88f,f*.5f,f*.58f,f*.25f,p); c.drawLine(f*.88f,f*.5f,f*.58f,f*.75f,p) }
            "layers" -> { c.drawLine(f*.5f,f*.15f,f*.88f,f*.38f,p); c.drawLine(f*.88f,f*.38f,f*.5f,f*.6f,p); c.drawLine(f*.5f,f*.6f,f*.12f,f*.38f,p); c.drawLine(f*.12f,f*.38f,f*.5f,f*.15f,p); c.drawLine(f*.18f,f*.58f,f*.5f,f*.78f,p); c.drawLine(f*.5f,f*.78f,f*.82f,f*.58f,p) }
            "undo" -> { c.drawArc(f*.25f,f*.25f,f*.82f,f*.82f,200f,230f,false,p); c.drawLine(f*.15f,f*.25f,f*.15f,f*.52f,p); c.drawLine(f*.15f,f*.25f,f*.42f,f*.25f,p) }
            "redo" -> { c.drawArc(f*.18f,f*.25f,f*.75f,f*.82f,110f,230f,false,p); c.drawLine(f*.85f,f*.25f,f*.85f,f*.52f,p); c.drawLine(f*.85f,f*.25f,f*.58f,f*.25f,p) }
            "import" -> { c.drawRect(f*.15f,f*.38f,f*.85f,f*.82f,p); c.drawLine(mid,f*.12f,mid,f*.58f,p); c.drawLine(f*.32f,f*.32f,mid,f*.12f,p); c.drawLine(f*.68f,f*.32f,mid,f*.12f,p) }
            "export" -> { c.drawRect(f*.15f,f*.48f,f*.85f,f*.85f,p); c.drawLine(mid,f*.12f,mid,f*.62f,p); c.drawLine(f*.32f,f*.42f,mid,f*.62f,p); c.drawLine(f*.68f,f*.42f,mid,f*.62f,p) }
            "clear" -> { c.drawRect(f*.25f,f*.3f,f*.75f,f*.82f,p); c.drawLine(f*.18f,f*.22f,f*.82f,f*.22f,p) }
            "zoom_in" -> { c.drawCircle(f*.42f,f*.42f,f*.25f,p); c.drawLine(f*.6f,f*.6f,f*.85f,f*.85f,p); c.drawLine(f*.42f,f*.3f,f*.42f,f*.54f,p); c.drawLine(f*.3f,f*.42f,f*.54f,f*.42f,p) }
            "zoom_out" -> { c.drawCircle(f*.42f,f*.42f,f*.25f,p); c.drawLine(f*.6f,f*.6f,f*.85f,f*.85f,p); c.drawLine(f*.3f,f*.42f,f*.54f,f*.42f,p) }
            else -> c.drawCircle(mid, mid, f*.28f, p)
        }
        val drawable = BitmapDrawable(resources, bmp).apply { setBounds(0, 0, size, size) }
        return Button(this).apply {
            text = label; textSize = 8.5f; isAllCaps = false; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(48, 49, 61))
            setCompoundDrawables(null, drawable, null, null); compoundDrawablePadding = 1
            setPadding(1, 2, 1, 2); setOnClickListener { action() }
        }
    }

    private fun setTool(t: DrawingBoard.Tool) {
        tool = t; board.setTool(t)
        Toast.makeText(this, "Tool: ${t.name.lowercase()}", Toast.LENGTH_SHORT).show()
    }

    private fun promptAddText() {
        val input = EditText(this).apply { hint = "Ketik teks atau dialog di sini..." }
        val sizeInput = EditText(this).apply { hint = "Ukuran font (default 36 px)"; setText("36"); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 10, 20, 10)
            addView(input)
            addView(sizeInput)
        }
        AlertDialog.Builder(this).setTitle("Tambah Teks / Dialog Webtoon")
            .setView(wrap)
            .setPositiveButton("Tempel di Tengah") { _, _ ->
                val text = input.text.toString()
                val fontSize = sizeInput.text.toString().toFloatOrNull() ?: 36f
                if (text.isNotBlank()) {
                    board.addTextToCanvas(text, fontSize, currentColor)
                    Toast.makeText(this, "Teks ditambahkan ke kanvas", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showCropDialog() {
        val options = arrayOf(
            "Potong Atas & Bawah (Webtoon Panel Trim)",
            "Pangkas Setengah Tinggi",
            "Custom Ukuran Crop..."
        )
        AlertDialog.Builder(this).setTitle("Tool Potong / Crop Kanvas")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> board.cropCanvas(board.canvasWidth, (board.canvasHeight * 0.8f).toInt())
                    1 -> board.cropCanvas(board.canvasWidth, board.canvasHeight / 2)
                    2 -> promptCustomCrop()
                }
                refreshStatus()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun promptCustomCrop() {
        val wInput = EditText(this).apply { hint = "Lebar baru (px)"; setText(board.canvasWidth.toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val hInput = EditText(this).apply { hint = "Tinggi baru (px)"; setText(board.canvasHeight.toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 10, 20, 10)
            addView(wInput); addView(hInput)
        }
        AlertDialog.Builder(this).setTitle("Custom Crop Kanvas")
            .setView(wrap)
            .setPositiveButton("Crop") { _, _ ->
                val w = wInput.text.toString().toIntOrNull() ?: board.canvasWidth
                val h = hInput.text.toString().toIntOrNull() ?: board.canvasHeight
                board.cropCanvas(w, h)
                refreshStatus()
                Toast.makeText(this, "Kanvas dicrop ke $w × $h px", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun chooseSymmetry() {
        val options = arrayOf("Off (No mirror)", "Vertical mirror", "Horizontal mirror", "Four-way mirror")
        AlertDialog.Builder(this).setTitle("Mirror / Symmetry")
            .setSingleChoiceItems(options, symmetry) { d, which ->
                symmetry = which; board.setSymmetry(which); d.dismiss(); refreshStatus()
                Toast.makeText(this, "Mirror: ${options[which]}", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun symmetryName() = arrayOf("Mirror off", "Vertical mirror", "Horizontal mirror", "Four-way")[symmetry]

    private fun chooseColor() {
        val wheel = ColorWheelView(this).apply { setColor(currentColor) }
        val hex = EditText(this).apply {
            hint = "#RRGGBB"; setSingleLine(true)
            setText(String.format("#%06X", 0xFFFFFF and currentColor))
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 4)
            addView(wheel, LinearLayout.LayoutParams(-1, 240))
            addView(hex)
        }
        val dialog = AlertDialog.Builder(this).setTitle("Roda Warna & Kode HEX")
            .setView(wrap)
            .setPositiveButton("Pakai Warna", null)
            .setNegativeButton("Batal", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                try {
                    currentColor = if (hex.text.isNullOrBlank()) wheel.selectedColor
                    else Color.parseColor(if (hex.text.toString().trim().startsWith("#")) hex.text.toString().trim() else "#" + hex.text.toString().trim())
                    board.setColor(currentColor); refreshStatus(); dialog.dismiss()
                } catch (_: Exception) {
                    hex.error = "Gunakan format #RRGGBB"
                }
            }
        }
        wheel.onColorChanged = { c -> hex.setText(String.format("#%06X", 0xFFFFFF and c)) }
        dialog.show()
    }

    private fun chooseBrushSize() {
        val seek = SeekBar(this).apply { max = 199; progress = 7 }
        val value = TextView(this).apply { text = "Ukuran kuas: 8 px"; setPadding(12, 8, 12, 8) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                val size = p + 1; value.text = "Ukuran kuas: $size px"; board.setBrushSize(size.toFloat())
            }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 4); addView(value); addView(seek) }.also { box ->
            AlertDialog.Builder(this).setTitle("Ukuran Kuas (1–200 px)").setView(box).setPositiveButton("Selesai", null).show()
        }
    }

    private fun chooseCanvasSize() {
        val sizes = arrayOf(
            "Webtoon Panel Standar (800 × 1280 px)",
            "Webtoon Long Strip (800 × 2560 px)",
            "Persegi / Square (1024 × 1024 px)",
            "Potret HD / Phone (1080 × 1920 px)",
            "Kecil / Pixel Art (512 × 512 px)"
        )
        val widths = intArrayOf(800, 800, 1024, 1080, 512)
        val heights = intArrayOf(1280, 2560, 1024, 1920, 512)

        AlertDialog.Builder(this).setTitle("Pilih Ukuran Kanvas (Webtoon & Custom)")
            .setItems(sizes) { _, which ->
                board.resizeCanvasCustom(widths[which], heights[which])
                refreshStatus()
                Toast.makeText(this, "Kanvas diset ke ${widths[which]} × ${heights[which]} px", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun showLayers() {
        val names = layers.mapIndexed { i, l ->
            "${if (i == selectedLayer) "▶ " else ""}${if (l.visible) "◉" else "○"}${if (l.locked) " 🔒 " else "  "}${l.name}"
        }.toMutableList()
        names.add("＋ Add new layer")
        AlertDialog.Builder(this).setTitle("Layers (v0.5)")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == layers.size) {
                    layers.add(ArtLayer("Layer ${layers.size + 1}", Bitmap.createBitmap(board.canvasWidth, board.canvasHeight, Bitmap.Config.ARGB_8888)))
                    selectedLayer = layers.lastIndex
                    board.setLayers(layers, selectedLayer)
                    showLayerActions(selectedLayer)
                } else {
                    selectedLayer = which
                    board.setLayers(layers, selectedLayer)
                    showLayerActions(which)
                }
                refreshStatus()
            }.setNegativeButton("Close", null).show()
    }

    private fun showLayerActions(index: Int) {
        val layer = layers[index]
        val actions = arrayOf(
            "Rename", if (layer.visible) "Hide layer" else "Show layer",
            if (layer.locked) "Unlock layer" else "Lock layer", "Delete layer"
        )
        AlertDialog.Builder(this).setTitle(layer.name).setItems(actions) { _, choice ->
            when (choice) {
                0 -> {
                    val edit = EditText(this).apply { setText(layer.name) }
                    AlertDialog.Builder(this).setTitle("Rename layer").setView(edit)
                        .setPositiveButton("Save") { _, _ ->
                            layer.name = edit.text.toString().ifBlank { layer.name }
                            showLayers()
                        }.setNegativeButton("Cancel", null).show()
                }
                1 -> { layer.visible = !layer.visible; board.invalidate(); showLayers() }
                2 -> { layer.locked = !layer.locked; showLayers() }
                3 -> if (layers.size > 1) {
                    layers.removeAt(index); selectedLayer = (selectedLayer - 1).coerceAtLeast(0)
                    board.setLayers(layers, selectedLayer); showLayers()
                } else Toast.makeText(this, "Minimal harus ada satu layer", Toast.LENGTH_SHORT).show()
            }
        }.setNegativeButton("Back") { _, _ -> showLayers() }.show()
    }

    @Deprecated("Legacy activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 410 && resultCode == RESULT_OK) data?.data?.let { addImportedLayer(it) }
    }

    private fun addImportedLayer(uri: Uri) {
        try {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw Exception("Gambar tidak terbaca")
            val target = Bitmap.createBitmap(board.canvasWidth, board.canvasHeight, Bitmap.Config.ARGB_8888)
            val c = Canvas(target)
            val scale = min(board.canvasWidth.toFloat() / bmp.width, board.canvasHeight.toFloat() / bmp.height)
            val w = bmp.width * scale; val h = bmp.height * scale
            val dst = RectF((board.canvasWidth - w) / 2, (board.canvasHeight - h) / 2,
                (board.canvasWidth + w) / 2, (board.canvasHeight + h) / 2)
            c.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            layers.add(ArtLayer("Imported ${layers.size}", target))
            selectedLayer = layers.lastIndex
            board.setLayers(layers, selectedLayer)
            Toast.makeText(this, "Gambar masuk sebagai layer baru", Toast.LENGTH_SHORT).show()
            refreshStatus()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal import: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showExportDialog() {
        val options = arrayOf("Background Putih (White)", "Background Hijau (Green)", "Background Transparan (Transparent)")
        AlertDialog.Builder(this)
            .setTitle("Pilih Background Ekspor (v0.5)")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> exportPng(Color.WHITE)
                    1 -> exportPng(Color.GREEN)
                    else -> exportPng(Color.TRANSPARENT)
                }
            }
            .show()
    }

    private fun exportPng(bgColor: Int) {
        try {
            val merged = Bitmap.createBitmap(board.canvasWidth, board.canvasHeight, Bitmap.Config.ARGB_8888)
            val c = Canvas(merged)
            c.drawColor(bgColor)
            layers.filter { it.visible }.forEach { c.drawBitmap(it.bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG)) }
            
            val filename = "ARTandPX_Webtoon_v05_${System.currentTimeMillis()}.png"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ARTandPX-Beta-v05")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw Exception("Tidak bisa membuat file")
                contentResolver.openOutputStream(uri)?.use { merged.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, filename)
                val fos = FileOutputStream(file)
                merged.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
                fos.close()
            }
            Toast.makeText(this, "PNG tersimpan di Pictures/ARTandPX-Beta-v05", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setMessage("Hapus isi layer aktif?")
            .setPositiveButton("Hapus") { _, _ -> board.clearCurrent() }
            .setNegativeButton("Batal", null).show()
    }

    private fun refreshStatus() {
        status.text = "${if (pixelMode) "PIXEL ART v0.5" else "WEBTOON / ART"} • ${layers.size} layer • ${board.canvasWidth}×${board.canvasHeight} • ${symmetryName()}"
    }
}

class DrawingBoard(context: Context, private var layersList: MutableList<ArtLayer>) : View(context) {
    enum class Tool { BRUSH, ERASER, LINE, RECT, OVAL }

    var canvasWidth = 800
        private set
    var canvasHeight = 1280
        private set

    private var activeLayerIndex = 0
    private var currentTool = Tool.BRUSH
    private var isPixelMode = false
    private var currentSymmetry = 0
    private var brushColor = Color.BLACK
    private var brushSize = 8f

    // Zoom & Pan
    private var scaleFactor = 1f
    private var posX = 0f
    private var posY = 0f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var isDragging = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(0.2f, 10f)
            invalidate()
            return true
        }
    })

    private class BoardState(val states: List<Bitmap>, val activeIdx: Int, val width: Int, val height: Int)
    private val undoStack = Stack<BoardState>()
    private val redoStack = Stack<BoardState>()

    private var startX = 0f
    private var startY = 0f
    private var currentX = 0f
    private var currentY = 0f
    private var isDrawing = false

    private val paint = Paint().apply {
        color = Color.BLACK
        strokeWidth = 8f
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        isAntiAlias = true
    }

    init {
        saveState()
    }

    fun setPixelMode(enabled: Boolean) {
        isPixelMode = enabled
        paint.isAntiAlias = !enabled
        invalidate()
    }

    fun setTool(t: Tool) { currentTool = t }
    fun setColor(c: Int) { 
        brushColor = c
        paint.color = c
    }
    fun setBrushSize(s: Float) { 
        brushSize = s
        paint.strokeWidth = s
    }
    fun setSymmetry(s: Int) { currentSymmetry = s }

    fun setLayers(list: MutableList<ArtLayer>, activeIdx: Int) {
        layersList = list
        activeLayerIndex = activeIdx.coerceIn(0, layersList.size - 1)
        invalidate()
    }

    fun resizeCanvasCustom(w: Int, h: Int) {
        canvasWidth = w
        canvasHeight = h
        for (l in layersList) {
            l.bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        }
        undoStack.clear()
        redoStack.clear()
        saveState()
        resetView()
        invalidate()
    }

    fun cropCanvas(newW: Int, newH: Int) {
        val w = newW.coerceAtLeast(64)
        val h = newH.coerceAtLeast(64)
        canvasWidth = w
        canvasHeight = h
        for (l in layersList) {
            val cropped = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(cropped)
            c.drawColor(Color.TRANSPARENT)
            c.drawBitmap(l.bitmap, 0f, 0f, null)
            l.bitmap = cropped
        }
        saveState()
        resetView()
        invalidate()
    }

    fun addTextToCanvas(text: String, fontSize: Float, textColor: Int) {
        if (activeLayerIndex !in layersList.indices) return
        val targetBmp = layersList[activeLayerIndex].bitmap
        val canvas = Canvas(targetBmp)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            textSize = fontSize
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(text, canvasWidth / 2f, canvasHeight / 2f, textPaint)
        saveState()
        invalidate()
    }

    private fun saveState() {
        val snapshot = layersList.map { it.bitmap.copy(it.bitmap.config ?: Bitmap.Config.ARGB_8888, true) }
        undoStack.push(BoardState(snapshot, activeLayerIndex, canvasWidth, canvasHeight))
        redoStack.clear()
    }

    fun undo() {
        if (undoStack.size > 1) {
            val current = undoStack.pop()
            redoStack.push(current)
            val prev = undoStack.peek()
            restoreState(prev)
            invalidate()
            Toast.makeText(context, "Undo Berhasil", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Batas Undo tercapai!", Toast.LENGTH_SHORT).show()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.pop()
            undoStack.push(next)
            restoreState(next)
            invalidate()
            Toast.makeText(context, "Redo Berhasil", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Tidak ada aksi untuk Redo!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun restoreState(state: BoardState) {
        canvasWidth = state.width
        canvasHeight = state.height
        for (i in layersList.indices) {
            if (i < state.states.size) {
                layersList[i].bitmap = state.states[i].copy(state.states[i].config ?: Bitmap.Config.ARGB_8888, true)
            }
        }
        activeLayerIndex = state.activeIdx.coerceIn(0, layersList.size - 1)
    }

    fun clearCurrent() {
        if (activeLayerIndex in layersList.indices && !layersList[activeLayerIndex].locked) {
            val bmp = layersList[activeLayerIndex].bitmap
            val c = Canvas(bmp)
            c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            saveState()
            invalidate()
        }
    }

    fun zoomBy(factor: Float) {
        scaleFactor = (scaleFactor * factor).coerceIn(0.2f, 10f)
        invalidate()
    }

    fun resetView() {
        scaleFactor = 1f
        posX = 0f
        posY = 0f
        invalidate()
    }

    private fun screenToCanvasX(screenX: Float): Float {
        return (screenX - posX - (width / 2f)) / scaleFactor + (canvasWidth / 2f)
    }

    private fun screenToCanvasY(screenY: Float): Float {
        return (screenY - posY - (height / 2f)) / scaleFactor + (canvasHeight / 2f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.translate(width / 2f + posX, height / 2f + posY)
        canvas.scale(scaleFactor, scaleFactor)
        canvas.translate(-canvasWidth / 2f, -canvasHeight / 2f)

        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, canvasWidth.toFloat(), canvasHeight.toFloat(), bgPaint)

        for (l in layersList) {
            if (l.visible) {
                canvas.drawBitmap(l.bitmap, 0f, 0f, null)
            }
        }

        // Live preview (ghost / shadow) while dragging shape tools
        if (isDrawing && (currentTool == Tool.LINE || currentTool == Tool.RECT || currentTool == Tool.OVAL)) {
            val previewPaint = Paint(paint).apply {
                color = brushColor
                alpha = 140
                style = Paint.Style.STROKE
                strokeWidth = if (isPixelMode) 32f else brushSize
            }
            if (isPixelMode) {
                val tileSize = 32f
                val gx1 = (startX / tileSize).toInt()
                val gy1 = (startY / tileSize).toInt()
                val gx2 = (currentX / tileSize).toInt()
                val gy2 = (currentY / tileSize).toInt()
                when (currentTool) {
                    Tool.LINE -> drawPixelBresenhamPreview(canvas, gx1, gy1, gx2, gy2, tileSize, previewPaint)
                    Tool.RECT -> {
                        val minX = min(gx1, gx2); val maxX = max(gx1, gx2)
                        val minY = min(gy1, gy2); val maxY = max(gy1, gy2)
                        for (gx in minX..maxX) {
                            for (gy in minY..maxY) {
                                if (gx == minX || gx == maxX || gy == minY || gy == maxY) {
                                    canvas.drawRect(gx * tileSize, gy * tileSize, (gx + 1) * tileSize, (gy + 1) * tileSize, previewPaint)
                                }
                            }
                        }
                    }
                    Tool.OVAL -> {
                        val minX = min(gx1, gx2); val maxX = max(gx1, gx2)
                        val minY = min(gy1, gy2); val maxY = max(gy1, gy2)
                        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f
                        val rx = (maxX - minX) / 2f; val ry = (maxY - minY) / 2f
                        if (rx > 0 && ry > 0) {
                            for (gx in minX..maxX) {
                                for (gy in minY..maxY) {
                                    val dx = (gx - cx) / rx
                                    val dy = (gy - cy) / ry
                                    if (dx * dx + dy * dy <= 1.0f) {
                                        canvas.drawRect(gx * tileSize, gy * tileSize, (gx + 1) * tileSize, (gy + 1) * tileSize, previewPaint)
                                    }
                                }
                            }
                        }
                    }
                    else -> {}
                }
            } else {
                when (currentTool) {
                    Tool.LINE -> canvas.drawLine(startX, startY, currentX, currentY, previewPaint)
                    Tool.RECT -> canvas.drawRect(min(startX, currentX), min(startY, currentY), max(startX, currentX), max(startY, currentY), previewPaint)
                    Tool.OVAL -> canvas.drawOval(min(startX, currentX), min(startY, currentY), max(startX, currentX), max(startY, currentY), previewPaint)
                    else -> {}
                }
            }
        }

        if (isPixelMode) {
            val gridPaint = Paint().apply {
                color = Color.parseColor("#22000000")
                strokeWidth = 1f
            }
            val tileSize = 32f
            var x = 0f
            while (x <= canvasWidth) {
                canvas.drawLine(x, 0f, x, canvasHeight.toFloat(), gridPaint)
                x += tileSize
            }
            var y = 0f
            while (y <= canvasHeight) {
                canvas.drawLine(0f, y, canvasWidth.toFloat(), y, gridPaint)
                y += tileSize
            }
        }

        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        val rawX = event.x
        val rawY = event.y

        val cX = screenToCanvasX(rawX).coerceIn(0f, canvasWidth.toFloat())
        val cY = screenToCanvasY(rawY).coerceIn(0f, canvasHeight.toFloat())

        if (scaleDetector.isInProgress) {
            isDrawing = false
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (event.pointerCount >= 2 || scaleDetector.isInProgress) {
                    isDrawing = false
                    isDragging = true
                    lastTouchX = rawX
                    lastTouchY = rawY
                } else {
                    if (activeLayerIndex in layersList.indices && layersList[activeLayerIndex].locked) {
                        return true
                    }
                    isDrawing = true
                    isDragging = false
                    startX = cX
                    startY = cY
                    currentX = cX
                    currentY = cY

                    if (currentTool == Tool.BRUSH || currentTool == Tool.ERASER) {
                        applyDrawingWithSymmetry(startX, startY, startX, startY)
                    }
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (isDrawing) {
                    isDrawing = false
                }
                isDragging = true
                lastTouchX = rawX
                lastTouchY = rawY
            }
            MotionEvent.ACTION_MOVE -> {
                if (scaleDetector.isInProgress) {
                    isDrawing = false
                    return true
                }
                if (event.pointerCount >= 2 || isDragging) {
                    posX += rawX - lastTouchX
                    posY += rawY - lastTouchY
                    lastTouchX = rawX
                    lastTouchY = rawY
                    invalidate()
                } else if (isDrawing) {
                    currentX = cX
                    currentY = cY
                    if (currentTool == Tool.BRUSH || currentTool == Tool.ERASER) {
                        applyDrawingWithSymmetry(startX, startY, currentX, currentY)
                        startX = currentX
                        startY = currentY
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isDrawing) {
                    if (currentTool != Tool.BRUSH && currentTool != Tool.ERASER) {
                        applyDrawingWithSymmetry(startX, startY, currentX, currentY)
                    }
                    saveState()
                    isDrawing = false
                    invalidate()
                }
                isDragging = false
            }
        }
        lastTouchX = rawX
        lastTouchY = rawY
        return true
    }

    private fun applyDrawingWithSymmetry(x1: Float, y1: Float, x2: Float, y2: Float) {
        if (activeLayerIndex !in layersList.indices) return
        val targetBmp = layersList[activeLayerIndex].bitmap
        val canvas = Canvas(targetBmp)

        val cx = canvasWidth / 2f
        val cy = canvasHeight / 2f

        val pointsToDraw = mutableListOf<Pair<Pair<Float, Float>, Pair<Float, Float>>>()
        pointsToDraw.add(Pair(Pair(x1, y1), Pair(x2, y2)))

        when (currentSymmetry) {
            1 -> { // Vertical mirror
                val mx1 = 2 * cx - x1
                val mx2 = 2 * cx - x2
                pointsToDraw.add(Pair(Pair(mx1, y1), Pair(mx2, y2)))
            }
            2 -> { // Horizontal mirror
                val my1 = 2 * cy - y1
                val my2 = 2 * cy - y2
                pointsToDraw.add(Pair(Pair(x1, my1), Pair(x2, my2)))
            }
            3 -> { // Four-way mirror
                val mx1 = 2 * cx - x1
                val mx2 = 2 * cx - x2
                val my1 = 2 * cy - y1
                val my2 = 2 * cy - y2
                pointsToDraw.add(Pair(Pair(mx1, y1), Pair(mx2, y2)))
                pointsToDraw.add(Pair(Pair(x1, my1), Pair(x2, my2)))
                pointsToDraw.add(Pair(Pair(mx1, my1), Pair(mx2, my2)))
            }
        }

        for (pt in pointsToDraw) {
            applySingleDrawing(canvas, pt.first.first, pt.first.second, pt.second.first, pt.second.second)
        }
        invalidate()
    }

    private fun applySingleDrawing(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        val drawPaint = Paint(paint).apply {
            if (currentTool == Tool.ERASER) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                color = Color.TRANSPARENT
            } else {
                xfermode = null
                color = brushColor
            }
        }

        if (isPixelMode) {
            val tileSize = 32f 
            val gx1 = (x1 / tileSize).toInt()
            val gy1 = (y1 / tileSize).toInt()
            val gx2 = (x2 / tileSize).toInt()
            val gy2 = (y2 / tileSize).toInt()

            when (currentTool) {
                Tool.BRUSH, Tool.ERASER -> drawPixelBresenham(canvas, gx1, gy1, gx2, gy2, tileSize, drawPaint)
                Tool.LINE -> drawPixelBresenham(canvas, gx1, gy1, gx2, gy2, tileSize, drawPaint)
                Tool.RECT -> {
                    val minX = min(gx1, gx2); val maxX = max(gx1, gx2)
                    val minY = min(gy1, gy2); val maxY = max(gy1, gy2)
                    for (gx in minX..maxX) {
                        for (gy in minY..maxY) {
                            if (gx == minX || gx == maxX || gy == minY || gy == maxY) {
                                val p = Paint(drawPaint).apply { style = Paint.Style.FILL }
                                canvas.drawRect(gx * tileSize, gy * tileSize, (gx + 1) * tileSize, (gy + 1) * tileSize, p)
                            }
                        }
                    }
                }
                Tool.OVAL -> {
                    val minX = min(gx1, gx2); val maxX = max(gx1, gx2)
                    val minY = min(gy1, gy2); val maxY = max(gy1, gy2)
                    val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f
                    val rx = (maxX - minX) / 2f; val ry = (maxY - minY) / 2f
                    if (rx > 0 && ry > 0) {
                        for (gx in minX..maxX) {
                            for (gy in minY..maxY) {
                                val dx = (gx - cx) / rx
                                val dy = (gy - cy) / ry
                                if (dx * dx + dy * dy <= 1.0f) {
                                    val p = Paint(drawPaint).apply { style = Paint.Style.FILL }
                                    canvas.drawRect(gx * tileSize, gy * tileSize, (gx + 1) * tileSize, (gy + 1) * tileSize, p)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            when (currentTool) {
                Tool.BRUSH, Tool.ERASER -> canvas.drawLine(x1, y1, x2, y2, drawPaint)
                Tool.LINE -> canvas.drawLine(x1, y1, x2, y2, drawPaint)
                Tool.RECT -> canvas.drawRect(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2), drawPaint)
                Tool.OVAL -> canvas.drawOval(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2), drawPaint)
            }
        }
    }

    private fun drawPixelBresenham(canvas: Canvas, x0: Int, y0: Int, x1: Int, y1: Int, tileSize: Float, p: Paint) {
        val dx = abs(x1 - x0)
        val dy = abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx - dy

        var cx = x0
        var cy = y0

        val fillPaint = Paint(p).apply { style = Paint.Style.FILL }

        while (true) {
            canvas.drawRect(cx * tileSize, cy * tileSize, (cx + 1) * tileSize, (cy + 1) * tileSize, fillPaint)
            if (cx == x1 && cy == y1) break
            val e2 = 2 * err
            if (e2 > -dy) {
                err -= dy
                cx += sx
            }
            if (e2 < dx) {
                err += dx
                cy += sy
            }
        }
    }

    private fun drawPixelBresenhamPreview(canvas: Canvas, x0: Int, y0: Int, x1: Int, y1: Int, tileSize: Float, p: Paint) {
        val dx = abs(x1 - x0)
        val dy = abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx - dy

        var cx = x0
        var cy = y0

        while (true) {
            canvas.drawRect(cx * tileSize, cy * tileSize, (cx + 1) * tileSize, (cy + 1) * tileSize, p)
            if (cx == x1 && cy == y1) break
            val e2 = 2 * err
            if (e2 > -dy) {
                err -= dy
                cx += sx
            }
            if (e2 < dx) {
                err += dx
                cy += sy
            }
        }
    }
}

class ColorWheelView(context: Context) : View(context) {
    var selectedColor: Int = Color.RED
        private set
    var onColorChanged: ((Int) -> Unit)? = null
    private val wheelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE }
    private var cx = 0f; private var cy = 0f; private var radius = 0f
    private val colors = IntArray(361) { i -> Color.HSVToColor(floatArrayOf(i.toFloat(), 1f, 1f)) }

    fun setColor(c: Int) { selectedColor = c; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        cx = width / 2f; cy = height / 2f; radius = min(width, height) * .43f
        for (i in 0 until 360) {
            wheelPaint.color = colors[i]
            canvas.drawArc(cx - radius, cy - radius, cx + radius, cy + radius, i.toFloat(), 1f, true, wheelPaint)
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(selectedColor, hsv)
        val angle = hsv[0]
        val r = radius * hsv[1]
        val rad = Math.toRadians(angle.toDouble())
        val mx = cx + (r * cos(rad)).toFloat()
        val my = cy + (r * sin(rad)).toFloat()
        canvas.drawCircle(mx, my, 16f, markerPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            val angle = ((Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())) + 360) % 360).toFloat()
            val sat = (dist / radius).coerceIn(0f, 1f)
            selectedColor = Color.HSVToColor(floatArrayOf(angle, sat, 1f))
            onColorChanged?.invoke(selectedColor)
            invalidate()
            return true
        }
        return super.onTouchEvent(event)
    }
}
