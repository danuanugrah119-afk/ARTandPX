# ARTandPX v2.3 Combined Source

This is a combined package based on v2.2, which includes the v2.1 drawing UI/pixel-mode baseline plus the v2.2 canvas and color additions.

## Included features in this source
- Art Biasa and Pixel Art mode switch. Pixel mode snaps strokes to an 8-pixel grid.
- Collapsible top toolbar.
- Brush, eraser, line, rectangle, ellipse.
- Adjustable brush size (1–200 px).
- Canvas size presets: 128, 256, 512, 1024, 2048 square. Existing layers are resized when changing canvas size.
- Color wheel and HEX color input.
- Symmetry: vertical, horizontal, four-way.
- Layers: add, select, rename, hide/show, lock/unlock, delete.
- Undo/redo for drawing strokes, import image as layer, export merged PNG.

## Important limitations
- Pixel mode is a basic grid-snapped pixel brush, not a complete pixel-art suite yet.
- Canvas sizes are square presets only.
- Color wheel selects hue/saturation; HEX entry allows exact colors.
- Advanced features such as bucket fill, eyedropper, custom canvas dimensions, project save/open, and full icon-only toolbar are not included yet.

## Build
Requires JDK 17 and Android Gradle Plugin 8.7.3. Open the project in Android Studio or use the GitHub Actions workflow after placing this source project in the repository in the expected folder.
