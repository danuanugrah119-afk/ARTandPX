# ARTandPX 2.4 – Drawing Tools Update

Android drawing app source project.

## Included in this source update
- Separate Art mode and Pixel Art mode.
- Art canvas uses a clean white background.
- Pixel Art canvas uses a clean white background with thin 8-document-pixel grid lines (no checkerboard).
- Pixel brush and shape endpoints snap to the document grid.
- Live dashed preview while dragging Line, Rectangle, and Oval tools.
- Rectangle can be wide/tall; Oval can be elliptical.
- Pinch with two fingers to zoom and pan the canvas; toolbar buttons provide zoom in/out and reset.
- Existing color wheel + HEX entry, brush size, canvas size, layers, mirror, undo/redo, import and PNG export retained.

## Build
Open this folder in Android Studio, or use GitHub Actions with Gradle 8.9 and JDK 17.

## Notes
This is an incremental source update. The project should be built and tested on a device before treating every interaction as production-ready. The current Pixel Art grid spacing is 8 document pixels; it is a visual/editing grid and is not exported into the PNG.
