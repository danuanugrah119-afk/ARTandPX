# ArtForge Studio — Android starter project

Prototype Android native untuk menggambar:
- Kanvas putih yang bisa digambar dengan sentuhan.
- Brush, penghapus, garis, persegi, dan oval.
- Mode Pixel sederhana.
- Palet warna cepat dan input HEX.
- Pengaturan ukuran brush, undo, clear, dan ekspor PNG.

## Build APK
Buka folder ini di Android Studio, tunggu Gradle sync, lalu pilih **Build > Build APK(s)**.
APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Project ini adalah fondasi awal, bukan aplikasi final. Fitur penggaris, busur derajat, perspektif 3D, panduan wajah, layer, zoom/pan, dan roda warna penuh belum diterapkan pada versi awal ini.
