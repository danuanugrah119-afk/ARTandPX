package com.artforge.studio

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var board: DrawingBoard
    private var activeColor = Color.BLACK
    private var activeTool = "Brush"
    private var pixelMode = false
    private lateinit var colorPreview: View
    private lateinit var modeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17,18,24)
        window.navigationBarColor = Color.rgb(17,18,24)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17,18,24))
            setPadding(12, 10, 12, 8)
        }
        val title = TextView(this).apply {
            text = "ArtForge Studio"
            textSize = 21f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 4, 12)
        }
        page.addView(title)
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("Brush", "Eraser", "Line", "Rect", "Circle").forEach { tool ->
            toolbar.addView(makeButton(tool) { activeTool = tool; board.setTool(tool); board.invalidate() },
                LinearLayout.LayoutParams(0, 46, 1f).apply { setMargins(2,0,2,0) })
        }
        page.addView(toolbar)
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        modeButton = makeButton("Mode: Normal") { pixelMode = !pixelMode; modeButton.text = if(pixelMode) "Mode: Pixel" else "Mode: Normal"; board.pixelMode = pixelMode }
        modeRow.addView(modeButton, LinearLayout.LayoutParams(0, 44, 1f).apply { setMargins(2,8,2,8) })
        modeRow.addView(makeButton("HEX / RGB") { showColorDialog() }, LinearLayout.LayoutParams(0,44,1f).apply { setMargins(2,8,2,8) })
        modeRow.addView(makeButton("Undo") { board.undo() }, LinearLayout.LayoutParams(0,44,1f).apply { setMargins(2,8,2,8) })
        page.addView(modeRow)
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        colorPreview = View(this).apply { setBackgroundColor(activeColor) }
        colorRow.addView(colorPreview, LinearLayout.LayoutParams(42,42).apply { setMargins(4,4,10,4) })
        val palette = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.MAGENTA, Color.CYAN, Color.rgb(255,140,0), Color.rgb(130,90,220))
        palette.forEach { c ->
            val swatch = View(this).apply {
                setBackgroundColor(c)
                setOnClickListener { activeColor = c; colorPreview.setBackgroundColor(c); board.strokeColor = c }
            }
            colorRow.addView(swatch, LinearLayout.LayoutParams(0,32,1f).apply { setMargins(3,0,3,0) })
        }
        page.addView(colorRow)
        board = DrawingBoard(this).apply { strokeColor = activeColor; setTool(activeTool) }
        page.addView(board, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0,10,0,8) })
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bottom.addView(makeButton("Clear") { AlertDialog.Builder(this@MainActivity).setMessage("Hapus semua gambar?").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> board.clear() }.show() },
            LinearLayout.LayoutParams(0,46,1f).apply { setMargins(2,0,2,0) })
        bottom.addView(makeButton("Brush −") { board.brushSize = (board.brushSize - 2f).coerceAtLeast(1f) },
            LinearLayout.LayoutParams(0,46,1f).apply { setMargins(2,0,2,0) })
        bottom.addView(makeButton("Brush +") { board.brushSize = (board.brushSize + 2f).coerceAtMost(80f) },
            LinearLayout.LayoutParams(0,46,1f).apply { setMargins(2,0,2,0) })
        bottom.addView(makeButton("Save PNG") { board.savePng(this@MainActivity) },
            LinearLayout.LayoutParams(0,46,1f).apply { setMargins(2,0,2,0) })
        page.addView(bottom)
        setContentView(page)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 10.5f; isAllCaps = false
        setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48,49,64)))
        setOnClickListener { action() }
    }

    private fun showColorDialog() {
        val input = EditText(this).apply { hint = "#RRGGBB atau #AARRGGBB"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Masukkan kode warna").setView(input)
            .setPositiveButton("Pakai") { _, _ ->
                try {
                    val raw = input.text.toString().trim()
                    activeColor = Color.parseColor(if(raw.startsWith("#")) raw else "#$raw")
                    colorPreview.setBackgroundColor(activeColor); board.strokeColor = activeColor
                } catch (_: Exception) { Toast.makeText(this, "Kode warna tidak valid", Toast.LENGTH_SHORT).show() }
            }.setNegativeButton("Batal", null).show()
    }
}

class DrawingBoard(ctx: android.content.Context) : View(ctx) {
    var strokeColor = Color.BLACK
    var brushSize = 8f
    var pixelMode = false
    private val paths = mutableListOf<Stroke>()
    private val undone = mutableListOf<Stroke>()
    private var current: Stroke? = null
    private var startX = 0f; private var startY = 0f; private var endX = 0f; private var endY = 0f
    private val bg = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private data class Stroke(val tool:String, val color:Int, val width:Float, val points:MutableList<Pair<Float,Float>>)

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(235,236,242))
        val margin = 12f
        val rect = RectF(margin, margin, width - margin, height - margin)
        canvas.drawRect(rect, bg)
        paths.forEach { drawStroke(canvas, it) }
        current?.let { drawStroke(canvas, it) }
        if (current != null && current!!.tool in listOf("Line","Rect","Circle")) drawShapePreview(canvas)
    }

    private fun drawStroke(canvas: Canvas, s: Stroke) {
        p.color = if(s.tool == "Eraser") Color.WHITE else s.color
        p.strokeWidth = if(s.tool == "Eraser") s.width * 2 else s.width
        if (s.tool == "Rect" || s.tool == "Circle" || s.tool == "Line") {
            if(s.points.size >= 2) {
                val a=s.points.first(); val b=s.points.last()
                when(s.tool) {
                    "Line" -> canvas.drawLine(a.first,a.second,b.first,b.second,p)
                    "Rect" -> canvas.drawRect(a.first,a.second,b.first,b.second,p)
                    "Circle" -> canvas.drawOval(RectF(a.first,a.second,b.first,b.second),p)
                }
            }
        } else if (s.points.size == 1) {
            val pt=s.points[0]; p.style=Paint.Style.FILL; canvas.drawCircle(pt.first,pt.second,p.strokeWidth/2,p); p.style=Paint.Style.STROKE
        } else {
            val path=Path()
            s.points.forEachIndexed { i, pt ->
                val x=if(pixelMode) (pt.first/8f).roundToInt()*8f else pt.first
                val y=if(pixelMode) (pt.second/8f).roundToInt()*8f else pt.second
                if(i==0) path.moveTo(x,y) else path.lineTo(x,y)
            }
            if(pixelMode) {
                p.style=Paint.Style.FILL
                s.points.forEach { pt -> canvas.drawRect(pt.first-3,pt.second-3,pt.first+3,pt.second+3,p) }
                p.style=Paint.Style.STROKE
            } else canvas.drawPath(path,p)
        }
    }

    private fun drawShapePreview(canvas: Canvas) {
        val s=current ?: return
        p.color=s.color; p.strokeWidth=s.width
        val a=s.points.firstOrNull() ?: return
        val b=s.points.lastOrNull() ?: return
        when(s.tool) {
            "Line" -> canvas.drawLine(a.first,a.second,b.first,b.second,p)
            "Rect" -> canvas.drawRect(a.first,a.second,b.first,b.second,p)
            "Circle" -> canvas.drawOval(RectF(a.first,a.second,b.first,b.second),p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x=e.x.coerceIn(12f,width-12f); val y=e.y.coerceIn(12f,height-12f)
        when(e.action) {
            MotionEvent.ACTION_DOWN -> {
                startX=x; startY=y
                val tool = if(pixelMode && activeToolName()=="Brush") "Pixel" else activeToolName()
                current=Stroke(tool,strokeColor,brushSize, mutableListOf(x to y))
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> {
                current?.points?.add(x to y); invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                current?.points?.add(x to y)
                current?.let { paths.add(it); undone.clear() }
                current=null; invalidate(); return true
            }
        }
        return true
    }

    // Tool selection is passed through the view tag by Activity.
    private fun activeToolName(): String = (tag as? String) ?: "Brush"
    fun setTool(name:String) { tag=name }
    fun undo() { if(paths.isNotEmpty()) undone.add(paths.removeAt(paths.lastIndex)); invalidate() }
    fun clear() { paths.clear(); undone.clear(); current=null; invalidate() }

    fun savePng(activity: Activity) {
        try {
            val bitmap=Bitmap.createBitmap(1600,1600,Bitmap.Config.ARGB_8888)
            val c=Canvas(bitmap); c.drawColor(Color.WHITE)
            val scale=min(1580f/width.coerceAtLeast(1),1580f/height.coerceAtLeast(1))
            c.save(); c.translate(10f,10f); c.scale(scale,scale)
            paths.forEach { drawStroke(c,it) }; c.restore()
            val name="ArtForge_${System.currentTimeMillis()}.png"
            val values=android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,name)
                put(android.provider.MediaStore.Images.Media.MIME_TYPE,"image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ArtForgeStudio")
            }
            val uri=activity.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)
            if(uri!=null) activity.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }
            Toast.makeText(activity,"PNG disimpan di Pictures/ArtForgeStudio",Toast.LENGTH_LONG).show()
        } catch(e:Exception) { Toast.makeText(activity,"Gagal menyimpan: ${e.message}",Toast.LENGTH_LONG).show() }
    }
}
