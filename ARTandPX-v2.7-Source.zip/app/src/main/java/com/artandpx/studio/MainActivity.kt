package com.artandpx.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.Stack
import kotlin.math.*

data class ArtLayer(
    var name: String,
    var bitmap: Bitmap,
    var visible: Boolean = true,
    var locked: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var board: DrawingBoard
    private lateinit var status: TextView
    private val layers = mutableListOf<ArtLayer>()
    private var selectedLayer = 0
    private var pixelMode = false
    private var symmetry = 0 // 0 off, 1 vertical, 2 horizontal, 3 four-way
    private var tool = DrawingBoard.Tool.BRUSH
    private var currentColor = Color.BLACK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,17,22)
        window.navigationBarColor = Color.rgb(16,17,22)
        layers.add(ArtLayer("Layer 1", Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888)))
        board = DrawingBoard(this, layers)
        board.setColor(currentColor)
        buildUi()
    }

    private var toolbarOpen = true
    private lateinit var toolbarPanel: LinearLayout

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16,17,22))
            setPadding(8, 6, 8, 6)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "ARTandPX v2.7 Fixed"; textSize = 19f; setTextColor(Color.WHITE); setPadding(6, 8, 6, 8)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("⌃  TOOLS") { toolbarOpen = !toolbarOpen; toolbarPanel.visibility = if (toolbarOpen) View.VISIBLE else View.GONE })
        root.addView(header)

        val modes = makeRow(
            button("✎  ART BIASA") { pixelMode = false; board.setPixelMode(false); refreshStatus() },
            button("▦  PIXEL ART") { pixelMode = true; board.setPixelMode(true); refreshStatus() }
        )
        root.addView(modes)
        status = TextView(this).apply {
            text = "ART BIASA • 1 layer"; textSize = 12f
            setTextColor(Color.LTGRAY); setPadding(5, 5, 5, 7)
        }
        root.addView(status)

        toolbarPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        toolbarPanel.addView(makeRow(
            iconButton("Brush", "brush") { setTool(DrawingBoard.Tool.BRUSH) },
            iconButton("Eraser", "eraser") { setTool(DrawingBoard.Tool.ERASER) },
            iconButton("Line", "line") { setTool(DrawingBoard.Tool.LINE) },
            iconButton("Rectangle", "rect") { setTool(DrawingBoard.Tool.RECT) },
            iconButton("Oval", "oval") { setTool(DrawingBoard.Tool.OVAL) }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Color", "color") { chooseColor() },
            iconButton("Brush size", "size") { chooseBrushSize() },
            iconButton("Canvas", "canvas") { chooseCanvasSize() },
            iconButton("Mirror", "mirror") { chooseSymmetry() },
            iconButton("Layers", "layers") { showLayers() },
            iconButton("Undo", "undo") { board.undo() },
            iconButton("Redo", "redo") { board.redo() }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Import", "import") {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
                startActivityForResult(intent, 410)
            },
            iconButton("Export", "export") { showExportDialog() },
            iconButton("Clear", "clear") { confirmClear() }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Zoom +", "zoom_in") { board.zoomBy(1.25f) },
            iconButton("Zoom −", "zoom_out") { board.zoomBy(0.8f) },
            iconButton("Reset", "reset") { board.resetView() }
        ))
        root.addView(toolbarPanel)

        val canvasFrame = FrameLayout(this).apply { setBackgroundColor(Color.rgb(37,38,45)) }
        canvasFrame.addView(board, FrameLayout.LayoutParams(-1, -1))
        root.addView(canvasFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val palette = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 4) }
        val colors = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW,
            Color.CYAN, Color.MAGENTA, Color.rgb(255,128,0), Color.rgb(128,80,220))
        colors.forEach { c ->
            val swatch = View(this).apply {
                setBackgroundColor(c)
                setOnClickListener { currentColor = c; board.setColor(c); refreshStatus() }
            }
            palette.addView(swatch, LinearLayout.LayoutParams(0, 32, 1f).apply { setMargins(3, 0, 3, 0) })
        }
        root.addView(palette)
        setContentView(root)
        refreshStatus()
    }

    private fun makeRow(vararg views: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 3, 0, 3)
            views.forEach { addView(it, LinearLayout.LayoutParams(0, (resources.displayMetrics.density * 62).toInt(), 1f).apply {
                setMargins(2, 0, 2, 0)
            }) }
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48,49,61))
            setOnClickListener { action() }
        }

    private fun iconButton(label: String, kind: String, action: () -> Unit): Button {
        val size = (resources.displayMetrics.density * 24).toInt().coerceAtLeast(24)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = size * .09f
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val f = size.toFloat(); val mid = f / 2f
        when (kind) {
            "brush" -> { c.drawLine(f*.22f,f*.78f,f*.72f,f*.28f,p); c.drawLine(f*.62f,f*.18f,f*.82f,f*.38f,p); c.drawOval(f*.12f,f*.68f,f*.35f,f*.9f,p) }
            "eraser" -> { val path = Path().apply { moveTo(f*.25f,f*.65f); lineTo(f*.55f,f*.2f); lineTo(f*.86f,f*.5f); lineTo(f*.56f,f*.85f); close() }; c.drawPath(path,p); c.drawLine(f*.43f,f*.72f,f*.7f,f*.72f,p) }
            "line" -> c.drawLine(f*.18f,f*.82f,f*.82f,f*.18f,p)
            "rect" -> c.drawRect(f*.18f,f*.2f,f*.82f,f*.8f,p)
            "oval" -> c.drawOval(f*.16f,f*.25f,f*.84f,f*.75f,p)
            "color" -> { c.drawCircle(mid,mid,f*.3f,p); c.drawCircle(mid,mid,f*.1f,p) }
            "size" -> { c.drawLine(f*.18f,f*.5f,f*.82f,f*.5f,p); c.drawCircle(f*.5f,f*.5f,f*.2f,p) }
            "canvas" -> { c.drawRect(f*.18f,f*.18f,f*.82f,f*.82f,p); c.drawLine(f*.18f,f*.4f,f*.82f,f*.4f,p) }
            "mirror" -> { c.drawLine(mid,f*.15f,mid,f*.85f,p); c.drawLine(f*.12f,f*.5f,f*.42f,f*.25f,p); c.drawLine(f*.12f,f*.5f,f*.42f,f*.75f,p); c.drawLine(f*.88f,f*.5f,f*.58f,f*.25f,p); c.drawLine(f*.88f,f*.5f,f*.58f,f*.75f,p) }
            "layers" -> { c.drawLine(f*.5f,f*.15f,f*.88f,f*.38f,p); c.drawLine(f*.88f,f*.38f,f*.5f,f*.6f,p); c.drawLine(f*.5f,f*.6f,f*.12f,f*.38f,p); c.drawLine(f*.12f,f*.38f,f*.5f,f*.15f,p); c.drawLine(f*.18f,f*.58f,f*.5f,f*.78f,p); c.drawLine(f*.5f,f*.78f,f*.82f,f*.58f,p) }
            "undo" -> { c.drawArc(f*.25f,f*.25f,f*.82f,f*.82f,200f,230f,false,p); c.drawLine(f*.15f,f*.25f,f*.15f,f*.52f,p); c.drawLine(f*.15f,f*.25f,f*.42f,f*.25f,p) }
            "redo" -> { c.drawArc(f*.18f,f*.25f,f*.75f,f*.82f,110f,230f,false,p); c.drawLine(f*.85f,f*.25f,f*.85f,f*.52f,p); c.drawLine(f*.85f,f*.25f,f*.58f,f*.25f,p) }
            "import" -> { c.drawRect(f*.15f,f*.38f,f*.85f,f*.82f,p); c.drawLine(mid,f*.12f,mid,f*.58f,p); c.drawLine(f*.32f,f*.32f,mid,f*.12f,p); c.drawLine(f*.68f,f*.32f,mid,f*.12f,p) }
            "export" -> { c.drawRect(f*.15f,f*.48f,f*.85f,f*.85f,p); c.drawLine(mid,f*.12f,mid,f*.62f,p); c.drawLine(f*.32f,f*.42f,mid,f*.62f,p); c.drawLine(f*.68f,f*.42f,mid,f*.62f,p) }
            "clear" -> { c.drawRect(f*.25f,f*.3f,f*.75f,f*.82f,p); c.drawLine(f*.18f,f*.22f,f*.82f,f*.22f,p) }
            "zoom_in" -> { c.drawCircle(f*.42f,f*.42f,f*.25f,p); c.drawLine(f*.6f,f*.6f,f*.85f,f*.85f,p); c.drawLine(f*.42f,f*.3f,f*.42f,f*.54f,p); c.drawLine(f*.3f,f*.42f,f*.54f,f*.42f,p) }
            "zoom_out" -> { c.drawCircle(f*.42f,f*.42f,f*.25f,p); c.drawLine(f*.6f,f*.6f,f*.85f,f*.85f,p); c.drawLine(f*.3f,f*.42f,f*.54f,f*.42f,p) }
            else -> c.drawCircle(mid, mid, f*.28f, p)
        }
        val drawable = BitmapDrawable(resources, bmp).apply { setBounds(0, 0, size, size) }
        return Button(this).apply {
            text = label; textSize = 9f; isAllCaps = false; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(48,49,61))
            setCompoundDrawables(null, drawable, null, null); compoundDrawablePadding = 1
            setPadding(1, 2, 1, 2); setOnClickListener { action() }
        }
    }

    private fun setTool(t: DrawingBoard.Tool) {
        tool = t; board.setTool(t)
        Toast.makeText(this, "${t.name.lowercase()} tool", Toast.LENGTH_SHORT).show()
    }

    private fun chooseSymmetry() {
        val options = arrayOf("Off", "Vertical mirror", "Horizontal mirror", "Four-way")
        AlertDialog.Builder(this).setTitle("Symmetry")
            .setSingleChoiceItems(options, symmetry) { d, which ->
                symmetry = which; board.setSymmetry(which); d.dismiss(); refreshStatus()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun symmetryName() = arrayOf("Mirror off", "Vertical", "Horizontal", "Four-way")[symmetry]

    private fun chooseColor() {
        val wheel = ColorWheelView(this).apply { setColor(currentColor) }
        val hex = EditText(this).apply {
            hint = "#RRGGBB"; setSingleLine(true)
            setText(String.format("#%06X", 0xFFFFFF and currentColor))
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 4)
            addView(wheel, LinearLayout.LayoutParams(-1, 240))
            addView(hex)
        }
        val dialog = AlertDialog.Builder(this).setTitle("Roda warna & kode HEX")
            .setView(wrap)
            .setPositiveButton("Pakai warna", null)
            .setNegativeButton("Batal", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                try {
                    currentColor = if (hex.text.isNullOrBlank()) wheel.selectedColor
                    else Color.parseColor(if (hex.text.toString().trim().startsWith("#")) hex.text.toString().trim() else "#" + hex.text.toString().trim())
                    board.setColor(currentColor); refreshStatus(); dialog.dismiss()
                } catch (_: Exception) {
                    hex.error = "Gunakan format #RRGGBB, contoh #FF8800"
                }
            }
        }
        wheel.onColorChanged = { c -> hex.setText(String.format("#%06X", 0xFFFFFF and c)) }
        dialog.show()
    }

    private fun chooseBrushSize() {
        val seek = SeekBar(this).apply { max = 199; progress = 7 }
        val value = TextView(this).apply { text = "Ukuran kuas: 8 px"; setPadding(12, 8, 12, 8) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                val size = p + 1; value.text = "Ukuran kuas: $size px"; board.setBrushSize(size.toFloat())
            }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 4); addView(value); addView(seek) }.also { box ->
            AlertDialog.Builder(this).setTitle("Ukuran kuas (1–200 px)").setView(box).setPositiveButton("Selesai", null).show()
        }
    }

    private fun chooseCanvasSize() {
        val sizes = arrayOf("128 × 128", "256 × 256", "512 × 512", "1024 × 1024", "2048 × 2048")
        val values = intArrayOf(128, 256, 512, 1024, 2048)
        AlertDialog.Builder(this).setTitle("Ukuran kanvas")
            .setItems(sizes) { _, which ->
                board.resizeCanvas(values[which])
                refreshStatus()
                Toast.makeText(this, "Kanvas ${values[which]} × ${values[which]} px", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun showLayers() {
        val names = layers.mapIndexed { i, l ->
            "${if (i == selectedLayer) "▶ " else ""}${if (l.visible) "◉" else "○"}${if (l.locked) " 🔒 " else "  "}${l.name}"
        }.toMutableList()
        names.add("＋ Add new layer")
        AlertDialog.Builder(this).setTitle("Layers")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == layers.size) {
                    layers.add(ArtLayer("Layer ${layers.size + 1}", Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)))
                    selectedLayer = layers.lastIndex
                    board.setLayers(layers, selectedLayer)
                    showLayerActions(selectedLayer)
                } else {
                    selectedLayer = which
                    board.setLayers(layers, selectedLayer)
                    showLayerActions(which)
                }
                refreshStatus()
            }.setNegativeButton("Close", null).show()
    }

    private fun showLayerActions(index: Int) {
        val layer = layers[index]
        val actions = arrayOf(
            "Rename", if (layer.visible) "Hide layer" else "Show layer",
            if (layer.locked) "Unlock layer" else "Lock layer", "Delete layer"
        )
        AlertDialog.Builder(this).setTitle(layer.name).setItems(actions) { _, choice ->
            when (choice) {
                0 -> {
                    val edit = EditText(this).apply { setText(layer.name) }
                    AlertDialog.Builder(this).setTitle("Rename layer").setView(edit)
                        .setPositiveButton("Save") { _, _ ->
                            layer.name = edit.text.toString().ifBlank { layer.name }
                            showLayers()
                        }.setNegativeButton("Cancel", null).show()
                }
                1 -> { layer.visible = !layer.visible; board.invalidate(); showLayers() }
                2 -> { layer.locked = !layer.locked; showLayers() }
                3 -> if (layers.size > 1) {
                    layers.removeAt(index); selectedLayer = (selectedLayer - 1).coerceAtLeast(0)
                    board.setLayers(layers, selectedLayer); showLayers()
                } else Toast.makeText(this, "Minimal harus ada satu layer", Toast.LENGTH_SHORT).show()
            }
        }.setNegativeButton("Back") { _, _ -> showLayers() }.show()
    }

    @Deprecated("Legacy activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 410 && resultCode == RESULT_OK) data?.data?.let { addImportedLayer(it) }
    }

    private fun addImportedLayer(uri: Uri) {
        try {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw Exception("Gambar tidak terbaca")
            val target = Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)
            val c = Canvas(target)
            val scale = min(board.canvasSize.toFloat() / bmp.width, board.canvasSize.toFloat() / bmp.height)
            val w = bmp.width * scale; val h = bmp.height * scale
            val dst = RectF((board.canvasSize - w) / 2, (board.canvasSize - h) / 2,
                (board.canvasSize + w) / 2, (board.canvasSize + h) / 2)
            c.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            layers.add(ArtLayer("Imported ${layers.size}", target))
            selectedLayer = layers.lastIndex
            board.setLayers(layers, selectedLayer)
            Toast.makeText(this, "Gambar masuk sebagai layer baru", Toast.LENGTH_SHORT).show()
            refreshStatus()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal import: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showExportDialog() {
        val options = arrayOf("Background Putih (White)", "Background Hijau (Green)", "Background Transparan (Transparent)")
        AlertDialog.Builder(this)
            .setTitle("Pilih Background Ekspor v2.7")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> exportPng(Color.WHITE)
                    1 -> exportPng(Color.GREEN)
                    else -> exportPng(Color.TRANSPARENT)
                }
            }
            .show()
    }

    private fun exportPng(bgColor: Int) {
        try {
            val merged = Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)
            val c = Canvas(merged)
            c.drawColor(bgColor)
            layers.filter { it.visible }.forEach { c.drawBitmap(it.bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG)) }
            
            val filename = "ARTandPX_v2.7_${System.currentTimeMillis()}.png"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ARTandPX")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw Exception("Tidak bisa membuat file")
                contentResolver.openOutputStream(uri)?.use { merged.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, filename)
                val fos = FileOutputStream(file)
                merged.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
                fos.close()
            }
            Toast.makeText(this, "PNG tersimpan di Pictures/ARTandPX", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setMessage("Hapus isi layer aktif?")
            .setPositiveButton("Hapus") { _, _ -> board.clearCurrent() }
            .setNegativeButton("Batal", null).show()
    }

    private fun refreshStatus() {
        status.text = "${if (pixelMode) "PIXEL ART • grid akurat" else "ART BIASA • smooth brush"} • ${layers.size} layer •