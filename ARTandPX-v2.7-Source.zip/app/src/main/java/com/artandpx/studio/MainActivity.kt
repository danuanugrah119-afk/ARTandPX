package com.artandpx.studio

import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.os.Environment
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.util.Stack

class MainActivity : AppCompatActivity() {

    private lateinit var drawingView: DrawingView
    private var currentTool = Tool.BRUSH

    enum class Tool { BRUSH, ERASER, LINE, TEXT }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Root Layout
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }

        // Top Toolbar
        val toolbar = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val toolbarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 16, 16, 16)
        }

        val btnBrush = createToolButton("Brush") { currentTool = Tool.BRUSH; drawingView.setTool(currentTool) }
        val btnEraser = createToolButton("Eraser") { currentTool = Tool.ERASER; drawingView.setTool(currentTool) }
        val btnLine = createToolButton("Line") { currentTool = Tool.LINE; drawingView.setTool(currentTool) }
        val btnText = createToolButton("Text") { 
            currentTool = Tool.TEXT
            drawingView.setTool(currentTool)
            showTextPrompt()
        }
        val btnUndo = createToolButton("Undo") { drawingView.undo() }
        val btnRedo = createToolButton("Redo") { drawingView.redo() }
        val btnExport = createToolButton("Export") { showExportDialog() }

        val togglePixel = ToggleButton(this).apply {
            text = "Pixel Art: OFF"
            textOn = "Pixel Art: ON"
            textOff = "Pixel Art: OFF"
            isChecked = false
            setOnCheckedChangeListener { _, isChecked ->
                drawingView.setPixelArtMode(isChecked)
            }
        }

        toolbarLayout.addView(btnBrush)
        toolbarLayout.addView(btnEraser)
        toolbarLayout.addView(btnLine)
        toolbarLayout.addView(btnText)
        toolbarLayout.addView(btnUndo)
        toolbarLayout.addView(btnRedo)
        toolbarLayout.addView(btnExport)
        toolbarLayout.addView(togglePixel)
        toolbar.addView(toolbarLayout)
        rootLayout.addView(toolbar)

        // Drawing View
        drawingView = DrawingView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        rootLayout.addView(drawingView)

        setContentView(rootLayout)
    }

    private fun createToolButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setOnClickListener { onClick() }
            setPadding(20, 10, 20, 10)
        }
    }

    private fun showTextPrompt() {
        val input = EditText(this).apply {
            hint = "Ketik teks di sini..."
        }
        AlertDialog.Builder(this)
            .setTitle("Tambah Teks")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val text = input.text.toString()
                if (text.isNotEmpty()) {
                    drawingView.setPendingText(text)
                    Toast.makeText(this, "Ketuk pada kanvas untuk menempatkan teks", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showExportDialog() {
        val options = arrayOf("Background Putih (White)", "Background Transparan (Transparent)")
        AlertDialog.Builder(this)
            .setTitle("Pilih Format Ekspor")
            .setItems(options) { _, which ->
                val whiteBg = (which == 0)
                drawingView.exportCanvas(whiteBg)
                Toast.makeText(this, "Gambar berhasil diekspor ke folder Pictures!", Toast.LENGTH_LONG).show()
            }
            .show()
    }

    class DrawingView(context: Context) : View(context) {
        private var canvasWidth = 800
        private var canvasHeight = 1200
        private val layers = ArrayList<Bitmap>()
        private var activeLayerIndex = 0

        // Undo & Redo Stacks
        private class State(val layerBitmaps: List<Bitmap>, val activeIndex: Int)
        private val undoStack = Stack<State>()
        private val redoStack = Stack<State>()

        private var currentTool = Tool.BRUSH
        private var isPixelArt = false
        private val pixelGridSize = 24 // Ukuran grid kotak pixel art

        private val paint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 12f
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            isAntiAlias = true
        }

        private var startX = 0f
        private var startY = 0f
        private var currentX = 0f
        private var currentY = 0f
        private var isDrawing = false
        private var pendingText: String? = null

        init {
            addNewLayer()
        }

        fun addNewLayer() {
            if (canvasWidth <= 0 || canvasHeight <= 0) {
                canvasWidth = 800
                canvasHeight = 1200
            }
            val bmp = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888)
            layers.add(bmp)
            activeLayerIndex = layers.size - 1
            saveState()
        }

        private fun saveState() {
            val copyList = layers.map { it.copy(it.config, true) }
            undoStack.push(State(copyList, activeLayerIndex))
            redoStack.clear()
        }

        fun undo() {
            if (undoStack.size > 1) {
                val currentState = undoStack.pop()
                redoStack.push(currentState)
                val prevState = undoStack.peek()
                restoreState(prevState)
                invalidate()
            } else {
                Toast.makeText(context, "Batas Undo tercapai!", Toast.LENGTH_SHORT).show()
            }
        }

        fun redo() {
            if (redoStack.isNotEmpty()) {
                val nextState = redoStack.pop()
                undoStack.push(nextState)
                restoreState(nextState)
                invalidate()
            } else {
                Toast.makeText(context, "Tidak ada aksi untuk Redo!", Toast.LENGTH_SHORT).show()
            }
        }

        private fun restoreState(state: State) {
            layers.clear()
            for (bmp in state.layerBitmaps) {
                layers.add(bmp.copy(bmp.config, true))
            }
            activeLayerIndex = state.activeIndex.coerceIn(0, layers.size - 1)
        }

        fun setTool(tool: Tool) {
            currentTool = tool
        }

        fun setPixelArtMode(enabled: Boolean) {
            isPixelArt = enabled
            paint.isAntiAlias = !enabled
            invalidate()
        }

        fun setPendingText(text: String) {
            pendingText = text
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            if (w > 0 && h > 0 && (canvasWidth != w || canvasHeight != h)) {
                canvasWidth = w
                canvasHeight = h
                for (i in layers.indices) {
                    val oldBmp = layers[i]
                    val newBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val canvas = android.graphics.Canvas(newBmp)
                    canvas.drawBitmap(oldBmp, 0f, 0f, null)
                    layers[i] = newBmp
                }
            }
        }

        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.parseColor("#2D2D2D")) // Background abu gelap kanvas kerja

            for (bmp in layers) {
                canvas.drawBitmap(bmp, 0f, 0f, null)
            }

            // Preview Line saat digeser
            if (isDrawing && currentTool == Tool.LINE) {
                if (isPixelArt) {
                    drawPixelLinePreview(canvas, startX, startY, currentX, currentY)
                } else {
                    canvas.drawLine(startX, startY, currentX, currentY, paint)
                }
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val x = event.x
            val y = event.y

            // Koreksi koordinat pixel art agar pas di tengah blok grid dan tidak offset
            val processedX = if (isPixelArt) (x / pixelGridSize).toInt() * pixelGridSize.toFloat() + pixelGridSize / 2f else x
            val processedY = if (isPixelArt) (y / pixelGridSize).toInt() * pixelGridSize.toFloat() + pixelGridSize / 2f else y

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (currentTool == Tool.TEXT && !pendingText.isNullOrEmpty()) {
                        drawTextOnCanvas(processedX, processedY, pendingText!!)
                        pendingText = null
                        saveState()
                        invalidate()
                        return true
                    }
                    isDrawing = true
                    startX = processedX
                    startY = processedY
                    currentX = processedX
                    currentY = processedY

                    if (currentTool == Tool.BRUSH || currentTool == Tool.ERASER) {
                        drawAction(startX, startY, startX, startY)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    currentX = processedX
                    currentY = processedY
                    if (currentTool == Tool.BRUSH || currentTool == Tool.ERASER) {
                        drawAction(startX, startY, currentX, currentY)
                        startX = currentX
                        startY = currentY
                    }
                    invalidate()
                }
                MotionEvent.ACTION_UP -> {
                    if (isDrawing) {
                        if (currentTool == Tool.LINE) {
                            drawAction(startX, startY, currentX, currentY)
                        }
                        saveState()
                        isDrawing = false
                        invalidate()
                    }
                }
            }
            return true
        }

        private fun drawAction(x1: Float, y1: Float, x2: Float, y2: Float) {
            if (activeLayerIndex !in layers.indices) return
            val bmp = layers[activeLayerIndex]
            val canvas = android.graphics.Canvas(bmp)

            val p = Paint(paint).apply {
                if (currentTool == Tool.ERASER) {
                    xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                    color = Color.TRANSPARENT
                }
            }

            if (isPixelArt) {
                drawPixelLineOrBrush(canvas, x1, y1, x2, y2, p)
            } else {
                canvas.drawLine(x1, y1, x2, y2, p)
            }
            invalidate()
        }

        private fun drawPixelLineOrBrush(canvas: android.graphics.Canvas, x1: Float, y1: Float, x2: Float, y2: Float, paint: Paint) {
            val x0 = (x1 / pixelGridSize).toInt()
            val y0 = (y1 / pixelGridSize).toInt()
            val xMax = (x2 / pixelGridSize).toInt()
            val yMax = (y2 / pixelGridSize).toInt()

            var dx = kotlin.math.abs(xMax - x0)
            var dy = kotlin.math.abs(yMax - y0)
            val sx = if (x0 < xMax) 1 else -1
            val sy = if (y0 < yMax) 1 else -1
            var err = dx - dy

            var cx = x0
            var cy = y0

            while (true) {
                canvas.drawRect(
                    (cx * pixelGridSize).toFloat(),
                    (cy * pixelGridSize).toFloat(),
                    ((cx + 1) * pixelGridSize).toFloat(),
                    ((cy + 1) * pixelGridSize).toFloat(),
                    paint
                )

                if (cx == xMax && cy == yMax) break
                val e2 = 2 * err
                if (e2 > -dy) {
                    err -= dy
                    cx += sx
                }
                if (e2 < dx) {
                    err += dx
                    cy += sy
                }
            }
        }

        private fun drawPixelLinePreview(canvas: android.graphics.Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
            val previewPaint = Paint(paint).apply { alpha = 120 }
            val x0 = (x1 / pixelGridSize).toInt()
            val y0 = (y1 / pixelGridSize).toInt()
            val xMax = (x2 / pixelGridSize).toInt()
            val yMax = (y2 / pixelGridSize).toInt()

            var dx = kotlin.math.abs(xMax - x0)
            var dy = kotlin.math.abs(yMax - y0)
            val sx = if (x0 < xMax) 1 else -1
            val sy = if (y0 < yMax) 1 else -1
            var err = dx - dy

            var cx = x0
            var cy = y0

            while (true) {
                canvas.drawRect(
                    (cx * pixelGridSize).toFloat(),
                    (cy * pixelGridSize).toFloat(),
                    ((cx + 1) * pixelGridSize).toFloat(),
                    ((cy + 1) * pixelGridSize).toFloat(),
                    previewPaint
                )
                if (cx == xMax && cy == yMax) break
                val e2 = 2 * err
                if (e2 > -dy) {
                    err -= dy
                    cx += sx
                }
                if (e2 < dx) {
                    err += dx
                    cy += sy
                }
            }
        }

        private fun drawTextOnCanvas(x: Float, y: Float, text: String) {
            if (activeLayerIndex !in layers.indices) return
            val bmp = layers[activeLayerIndex]
            val canvas = android.graphics.Canvas(bmp)
            val textPaint = Paint(paint).apply {
                style = Paint.Style.FILL
                textSize = 64f
                xfermode = null
            }
            canvas.drawText(text, x, y, textPaint)
        }

        fun exportCanvas(whiteBackground: Boolean) {
            val exportBmp = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(exportBmp)

            if (whiteBackground) {
                canvas.drawColor(Color.WHITE)
            } else {
                canvas.drawColor(Color.TRANSPARENT)
            }

            for (bmp in layers) {
                canvas.drawBitmap(bmp, 0f, 0f, null)
            }

            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "ArtAndPx_${System.currentTimeMillis()}.png")
            val fos = FileOutputStream(file)
            exportBmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
            fos.flush()
            fos.close()
        }
    }
}
