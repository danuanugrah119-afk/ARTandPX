package com.artandpx.studio

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Toast
import java.util.Stack
import kotlin.math.*

class DrawingBoard(context: Context, private var layersList: MutableList<ArtLayer>) : View(context) {
    enum class Tool { BRUSH, ERASER, LINE, RECT, OVAL, TEXT, CUT, MOVE }

    enum class BrushType(val label: String) {
        KUAS("Kuas"), PENA("Pena"), KALIGRAFI("Kaligrafi"), SPIDOL("Spidol"),
        PENSIL("Pensil"), AIRBRUSH("Airbrush"), SEMPROT("Semprot")
    }

    companion object {
        private const val UNDO_BUDGET = 160L * 1024L * 1024L
        private const val SOFTWARE_LAYER_LIMIT = 4096
    }

    // Kanvas sekarang bisa persegi panjang (mis. Webtoon 800 x 6000)
    var canvasW = 1024
        private set
    var canvasH = 1024
        private set

    var activeLayerIndex = 0
        private set

    // Callback ke Activity
    var onLayersChanged: (() -> Unit)? = null
    var onTextPlace: ((Float, Float) -> Unit)? = null
    var onCutSelected: ((Rect) -> Unit)? = null

    private var currentTool = Tool.BRUSH
    private var brushType = BrushType.KUAS
    private var isPixelMode = false
    private var currentSymmetry = 0 // 0: off, 1: vertical, 2: horizontal, 3: four-way
    private var brushColor = Color.BLACK
    private var brushSize = 8f
    private var inkWidth = 6f
    private val rng = java.util.Random()

    // Zoom & Pan
    private var scaleFactor = 1f
    private var posX = 0f
    private var posY = 0f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var isDragging = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(0.1f, 10f)
            invalidate()
            return true
        }
    })

    // Undo & Redo (sekarang menyimpan struktur layer juga, jadi salin/potong/hapus layer bisa di-undo)
    private class LayerSnap(val layer: ArtLayer, val bmp: Bitmap)
    private class BoardState(val snaps: List<LayerSnap>, val activeIdx: Int)
    private val undoStack = Stack<BoardState>()
    private val redoStack = Stack<BoardState>()

    private var startX = 0f
    private var startY = 0f
    private var currentX = 0f
    private var currentY = 0f
    private var isDrawing = false

    // Alat potong & geser
    private var selRect: RectF? = null
    private var downRawX = 0f
    private var downRawY = 0f
    private var moveDx = 0f
    private var moveDy = 0f

    private val paint = Paint().apply {
        color = Color.BLACK
        strokeWidth = 8f
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        isAntiAlias = true
    }

    private val isTall: Boolean
        get() = canvasH > canvasW * 1.5f

    init {
        saveState()
    }

    // ---------------------------------------------------------------- setters

    fun setPixelMode(enabled: Boolean) {
        isPixelMode = enabled
        paint.isAntiAlias = !enabled
        invalidate()
    }

    fun setTool(t: Tool) {
        currentTool = t
        if (t != Tool.CUT) selRect = null
        invalidate()
    }

    fun setBrushType(t: BrushType) { brushType = t }

    fun setColor(c: Int) {
        brushColor = c
        paint.color = c
    }

    fun setBrushSize(s: Float) {
        brushSize = s
        paint.strokeWidth = s
    }

    fun setSymmetry(s: Int) { currentSymmetry = s }

    fun setLayers(list: MutableList<ArtLayer>, activeIdx: Int) {
        layersList = list
        activeLayerIndex = activeIdx.coerceIn(0, layersList.size - 1)
        invalidate()
    }

    fun selectLayer(idx: Int) {
        activeLayerIndex = idx.coerceIn(0, layersList.size - 1)
        invalidate()
    }

    fun clearSelection() {
        selRect = null
        invalidate()
    }

    // ----------------------------------------------------------------- canvas

    private fun updateLayerType() {
        // Bitmap yang sangat panjang bisa melebihi batas tekstur GPU -> pakai render software
        val big = max(canvasW, canvasH) > SOFTWARE_LAYER_LIMIT
        setLayerType(if (big) LAYER_TYPE_SOFTWARE else LAYER_TYPE_NONE, null)
    }

    fun resizeCanvas(newW: Int, newH: Int): Boolean {
        dropAllStates()
        val fresh = ArrayList<Bitmap>()
        try {
            for (l in layersList) fresh.add(Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888))
        } catch (e: OutOfMemoryError) {
            fresh.forEach { it.recycle() }
            saveState()
            Toast.makeText(context, "Memori tidak cukup untuk kanvas $newW × $newH", Toast.LENGTH_LONG).show()
            return false
        }
        canvasW = newW
        canvasH = newH
        layersList.forEachIndexed { i, l -> l.bitmap = fresh[i] }
        selRect = null
        saveState()
        updateLayerType()
        resetView()
        return true
    }

    fun visibleTopY(): Float = screenToCanvasY(0f).coerceIn(0f, canvasH.toFloat())

    // ------------------------------------------------------------ undo / redo

    private fun dropState(s: BoardState) {
        s.snaps.forEach { if (!it.bmp.isRecycled) it.bmp.recycle() }
    }

    private fun dropAllStates() {
        undoStack.forEach { dropState(it) }
        redoStack.forEach { dropState(it) }
        undoStack.clear()
        redoStack.clear()
    }

    private fun saveState() {
        val snaps = layersList.map { LayerSnap(it, it.bitmap.copy(Bitmap.Config.ARGB_8888, true)) }
        redoStack.forEach { dropState(it) }
        redoStack.clear()
        undoStack.push(BoardState(snaps, activeLayerIndex))

        // Batasi jumlah undo supaya kanvas panjang tidak menghabiskan memori
        var bytes = 0L
        layersList.forEach { bytes += it.bitmap.byteCount.toLong() }
        val maxStates = (UNDO_BUDGET / max(1L, bytes)).toInt().coerceIn(3, 30)
        while (undoStack.size > maxStates) {
            dropState(undoStack.removeAt(0))
        }
    }

    /** Dipanggil Activity setelah mengubah struktur layer. */
    fun commit() = saveState()

    fun undo() {
        if (undoStack.size > 1) {
            val current = undoStack.pop()
            redoStack.push(current)
            val prev = undoStack.peek()
            restoreState(prev)
            invalidate()
            Toast.makeText(context, "Undo Berhasil", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Batas Undo tercapai!", Toast.LENGTH_SHORT).show()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.pop()
            undoStack.push(next)
            restoreState(next)
            invalidate()
            Toast.makeText(context, "Redo Berhasil", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Tidak ada aksi untuk Redo!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun restoreState(state: BoardState) {
        layersList.clear()
        for (s in state.snaps) {
            s.layer.bitmap = s.bmp.copy(Bitmap.Config.ARGB_8888, true)
            layersList.add(s.layer)
        }
        activeLayerIndex = state.activeIdx.coerceIn(0, layersList.size - 1)
        onLayersChanged?.invoke()
    }

    fun clearCurrent() {
        if (activeLayerIndex in layersList.indices && !layersList[activeLayerIndex].locked) {
            val bmp = layersList[activeLayerIndex].bitmap
            val c = Canvas(bmp)
            c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            saveState()
            invalidate()
        }
    }

    // ------------------------------------------------------------- layer ops

    private fun toastLocked() {
        Toast.makeText(context, "Layer terkunci", Toast.LENGTH_SHORT).show()
    }

    fun addLayer(name: String): Boolean = addLayerWithBitmap(name, null)

    fun addLayerWithBitmap(name: String, bmp: Bitmap?): Boolean {
        return try {
            val b = bmp ?: Bitmap.createBitmap(canvasW, canvasH, Bitmap.Config.ARGB_8888)
            layersList.add(ArtLayer(name, b))
            activeLayerIndex = layersList.lastIndex
            saveState()
            onLayersChanged?.invoke()
            invalidate()
            true
        } catch (e: OutOfMemoryError) {
            Toast.makeText(context, "Memori tidak cukup untuk layer baru", Toast.LENGTH_LONG).show()
            false
        }
    }

    fun deleteLayer(index: Int): Boolean {
        if (layersList.size <= 1 || index !in layersList.indices) return false
        layersList.removeAt(index)
        activeLayerIndex = (index - 1).coerceAtLeast(0)
        saveState()
        onLayersChanged?.invoke()
        invalidate()
        return true
    }

    /** SALIN layer / gambar import: dibuat duplikat tepat di atas layer asal. */
    fun duplicateLayer(index: Int = activeLayerIndex): Boolean {
        if (index !in layersList.indices) return false
        return try {
            val src = layersList[index]
            val copy = ArtLayer(src.name + " salinan", src.bitmap.copy(Bitmap.Config.ARGB_8888, true), src.visible, false)
            layersList.add(index + 1, copy)
            activeLayerIndex = index + 1
            saveState()
            onLayersChanged?.invoke()
            invalidate()
            Toast.makeText(context, "Layer disalin: ${copy.name}", Toast.LENGTH_SHORT).show()
            true
        } catch (e: OutOfMemoryError) {
            Toast.makeText(context, "Memori tidak cukup untuk menyalin layer", Toast.LENGTH_LONG).show()
            false
        }
    }

    /** POTONG area persegi dari layer aktif; opsional dipindah jadi layer baru. */
    fun cutRegion(r: Rect, toNewLayer: Boolean) {
        val layer = layersList.getOrNull(activeLayerIndex) ?: return
        if (layer.locked) { toastLocked(); return }
        val region = Rect(0, 0, canvasW, canvasH)
        if (!region.intersect(r)) return
        try {
            val piece = if (toNewLayer) Bitmap.createBitmap(canvasW, canvasH, Bitmap.Config.ARGB_8888) else null
            if (piece != null) Canvas(piece).drawBitmap(layer.bitmap, region, region, null)

            val c = Canvas(layer.bitmap)
            c.save()
            c.clipRect(region)
            c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            c.restore()

            if (piece != null) {
                layersList.add(activeLayerIndex + 1, ArtLayer(layer.name + " (potongan)", piece))
                activeLayerIndex += 1
            }
            saveState()
            onLayersChanged?.invoke()
            invalidate()
        } catch (e: OutOfMemoryError) {
            Toast.makeText(context, "Memori tidak cukup", Toast.LENGTH_LONG).show()
        }
    }

    /** CROP: hanya area terpilih yang tersisa di layer aktif. */
    fun cropToRegion(r: Rect) {
        val layer = layersList.getOrNull(activeLayerIndex) ?: return
        if (layer.locked) { toastLocked(); return }
        val region = Rect(0, 0, canvasW, canvasH)
        if (!region.intersect(r)) return
        try {
            val keep = Bitmap.createBitmap(region.width(), region.height(), Bitmap.Config.ARGB_8888)
            Canvas(keep).drawBitmap(layer.bitmap, region, Rect(0, 0, region.width(), region.height()), null)
            val c = Canvas(layer.bitmap)
            c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            c.drawBitmap(keep, region.left.toFloat(), region.top.toFloat(), null)
            keep.recycle()
            saveState()
            invalidate()
        } catch (e: OutOfMemoryError) {
            Toast.makeText(context, "Memori tidak cukup", Toast.LENGTH_LONG).show()
        }
    }

    private fun commitMove() {
        val dx = moveDx.roundToInt()
        val dy = moveDy.roundToInt()
        moveDx = 0f
        moveDy = 0f
        if (dx == 0 && dy == 0) return
        val layer = layersList.getOrNull(activeLayerIndex) ?: return
        try {
            val nb = Bitmap.createBitmap(canvasW, canvasH, Bitmap.Config.ARGB_8888)
            Canvas(nb).drawBitmap(layer.bitmap, dx.toFloat(), dy.toFloat(), null)
            layer.bitmap = nb
            saveState()
        } catch (e: OutOfMemoryError) {
            Toast.makeText(context, "Memori tidak cukup", Toast.LENGTH_LONG).show()
        }
    }

    /** TEKS: langsung diketik, tidak perlu ditulis pakai brush. (x, y) = titik tengah teks. */
    fun drawTextAt(text: String, x: Float, y: Float, typeface: Typeface, sizePx: Float, color: Int) {
        val layer = layersList.getOrNull(activeLayerIndex) ?: return
        if (layer.locked) { toastLocked(); return }
        val c = Canvas(layer.bitmap)
        val tp = Paint().apply {
            this.typeface = typeface
            textSize = sizePx
            this.color = color
            style = Paint.Style.FILL
            textAlign = Paint.Align.CENTER
            isAntiAlias = !isPixelMode
        }
        val fm = tp.fontMetrics
        val lines = text.split("\n")
        val lineH = fm.descent - fm.ascent + fm.leading
        val totalH = lineH * lines.size
        var baseline = y - totalH / 2f - fm.ascent
        for (line in lines) {
            c.drawText(line, x, baseline, tp)
            baseline += lineH
        }
        saveState()
        invalidate()
    }

    // ---------------------------------------------------------------- view

    fun zoomBy(factor: Float) {
        scaleFactor = (scaleFactor * factor).coerceIn(0.1f, 10f)
        invalidate()
    }

    fun resetView() {
        if (isTall && width > 0) {
            // Webtoon: pas lebar layar, mulai dari paling atas
            scaleFactor = (width.toFloat() / canvasW).coerceIn(0.1f, 10f)
            posX = 0f
            posY = -height / 2f + canvasH * scaleFactor / 2f
        } else {
            scaleFactor = 1f
            posX = 0f
            posY = 0f
        }
        invalidate()
    }

    private fun screenToCanvasX(screenX: Float): Float {
        return (screenX - posX - (width / 2f)) / scaleFactor + (canvasW / 2f)
    }

    private fun screenToCanvasY(screenY: Float): Float {
        return (screenY - posY - (height / 2f)) / scaleFactor + (canvasH / 2f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.translate(width / 2f + posX, height / 2f + posY)
        canvas.scale(scaleFactor, scaleFactor)
        canvas.translate(-canvasW / 2f, -canvasH / 2f)

        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, canvasW.toFloat(), canvasH.toFloat(), bgPaint)

        for ((i, l) in layersList.withIndex()) {
            if (!l.visible) continue
            if (isDrawing && currentTool == Tool.MOVE && i == activeLayerIndex && (moveDx != 0f || moveDy != 0f)) {
                canvas.drawBitmap(l.bitmap, moveDx, moveDy, null)
            } else {
                canvas.drawBitmap(l.bitmap, 0f, 0f, null)
            }
        }

        // Live preview (ghost / shadow) while dragging shape tools
        if (isDrawing && (currentTool == Tool.LINE || currentTool == Tool.RECT || currentTool == Tool.OVAL)) {
            val previewPaint = Paint(paint).apply {
                color = brushColor
                alpha = 140
                style = Paint.Style.STROKE
                strokeWidth = if (isPixelMode) 32f else brushSize
            }
            if (isPixelMode) {
                val tileSize = 32f
                val gx1 = (startX / tileSize).toInt()
                val gy1 = (startY / tileSize).toInt()
                val gx2 = (currentX / tileSize).toInt()
                val gy2 = (currentY / tileSize).toInt()
                when (currentTool) {
                    Tool.LINE -> drawPixelBresenhamPreview(canvas, gx1, gy1, gx2, gy2, tileSize, previewPaint)
                    Tool.RECT -> {
                        val minX = min(gx1, gx2); val maxX = max(gx1, gx2)
                        val minY = min(gy1, gy2); val maxY = max(gy1, gy2)
                        for (gx in minX..maxX) {
                            for (gy in minY..maxY) {
                                if (gx == minX || gx == maxX || gy == minY || gy == maxY) {
                                    canvas.drawRect(gx * tileSize, gy * tileSize, (gx + 1) * tileSize, (gy + 1) * tileSize, previewPaint)
                                }
                            }
                        }
                    }
                    Tool.OVAL -> {
                        val minX = min(gx1, gx2); val maxX = max(gx1, gx2)
                        val minY = min(gy1, gy2); val maxY = max(gy1, gy2)
                        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f
                        val rx = (maxX - minX) / 2f; val ry = (maxY - minY) / 2f
                        if (rx > 0 && ry > 0) {
                            for (gx in minX..maxX) {
                                for (gy in minY..maxY) {
                                    val dx = (gx - cx) / rx
                                    val dy = (gy - cy) / ry
                                    if (dx * dx + dy * dy <= 1.0f) {
                                        canvas.drawRect(gx * tileSize, gy * tileSize, (gx + 1) * tileSize, (gy + 1) * tileSize, previewPaint)
                                    }
                                }
                            }
                        }
                    }
                    else -> {}
                }
            } else {
                when (currentTool) {
                    Tool.LINE -> canvas.drawLine(startX, startY, currentX, currentY, previewPaint)
                    Tool.RECT -> canvas.drawRect(min(startX, currentX), min(startY, currentY), max(startX, currentX), max(startY, currentY), previewPaint)
                    Tool.OVAL -> canvas.drawOval(min(startX, currentX), min(startY, currentY), max(startX, currentX), max(startY, currentY), previewPaint)
                    else -> {}
                }
            }
        }

        if (isPixelMode) {
            val gridPaint = Paint().apply {
                color = Color.parseColor("#22000000")
                strokeWidth = 1f
            }
            val tileSize = 32f
            var x = 0f
            while (x <= canvasW) {
                canvas.drawLine(x, 0f, x, canvasH.toFloat(), gridPaint)
                x += tileSize
            }
            var y = 0f
            while (y <= canvasH) {
                canvas.drawLine(0f, y, canvasW.toFloat(), y, gridPaint)
                y += tileSize
            }
        }

        drawOverlays(canvas)

        canvas.restore()
    }

    private fun drawOverlays(canvas: Canvas) {
        val sw = 2f / scaleFactor

        // Tanda silang titik penaruh teks
        if (isDrawing && currentTool == Tool.TEXT) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = sw
                color = Color.rgb(255, 64, 129)
            }
            val a = 24f / scaleFactor
            canvas.drawLine(currentX - a, currentY, currentX + a, currentY, p)
            canvas.drawLine(currentX, currentY - a, currentX, currentY + a, p)
        }

        // Kotak pilihan alat Potong
        val rect: RectF? = if (isDrawing && currentTool == Tool.CUT) {
            RectF(min(startX, currentX), min(startY, currentY), max(startX, currentX), max(startY, currentY))
        } else {
            selRect
        }
        if (rect != null) {
            val fill = Paint().apply {
                color = Color.argb(40, 0, 150, 255)
                style = Paint.Style.FILL
            }
            canvas.drawRect(rect, fill)
            val white = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = sw
                color = Color.WHITE
            }
            val dashed = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = sw
                color = Color.BLACK
                pathEffect = DashPathEffect(floatArrayOf(10f / scaleFactor, 10f / scaleFactor), 0f)
            }
            canvas.drawRect(rect, white)
            canvas.drawRect(rect, dashed)
        }
    }

    private fun updateInk(event: MotionEvent, dx: Float, dy: Float) {
        val target = if (event.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS) {
            brushSize * (0.25f + 0.9f * event.pressure.coerceIn(0f, 1f))
        } else {
            val speed = hypot(dx, dy)
            brushSize * (1.1f - 0.8f * (speed / (speed + brushSize * 0.5f + 6f)))
        }
        inkWidth = (inkWidth * 0.75f + target * 0.25f).coerceAtLeast(1f)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        val rawX = event.x
        val rawY = event.y

        val cX = screenToCanvasX(rawX).coerceIn(0f, canvasW.toFloat())
        val cY = screenToCanvasY(rawY).coerceIn(0f, canvasH.toFloat())

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                    if (activeLayerIndex in layersList.indices && layersList[activeLayerIndex].locked) {
                        return true
                    }
                    isDrawing = true
                    startX = cX
                    startY = cY
                    currentX = cX
                    currentY = cY
                    downRawX = rawX
                    downRawY = rawY
                    moveDx = 0f
                    moveDy = 0f

                    if (currentTool == Tool.BRUSH || currentTool == Tool.ERASER) {
                        inkWidth = brushSize * 0.8f
                        applyDrawingWithSymmetry(startX, startY, startX, startY)
                    }
                } else if (event.pointerCount >= 2) {
                    isDrawing = false
                    isDragging = true
                    lastTouchX = rawX
                    lastTouchY = rawY
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // Jari kedua = pan/zoom, batalkan gambar yang sedang berjalan
                if (isDrawing) {
                    if (currentTool == Tool.BRUSH || currentTool == Tool.ERASER) saveState()
                    isDrawing = false
                    moveDx = 0f
                    moveDy = 0f
                }
                isDragging = true
                lastTouchX = rawX
                lastTouchY = rawY
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (scaleDetector.isInProgress) {
                    isDrawing = false
                    lastTouchX = rawX
                    lastTouchY = rawY
                    return true
                }
                if (event.pointerCount >= 2 || isDragging) {
                    posX += rawX - lastTouchX
                    posY += rawY - lastTouchY
                    lastTouchX = rawX
                    lastTouchY = rawY
                    invalidate()
                } else if (isDrawing) {
                    currentX = cX
                    currentY = cY
                    when (currentTool) {
                        Tool.BRUSH, Tool.ERASER -> {
                            if (currentTool == Tool.BRUSH && brushType == BrushType.PENA) {
                                updateInk(event, currentX - startX, currentY - startY)
                            }
                            applyDrawingWithSymmetry(startX, startY, currentX, currentY)
                            startX = currentX
                            startY = currentY
                        }
                        Tool.MOVE -> {
                            var dx = (rawX - downRawX) / scaleFactor
                            var dy = (rawY - downRawY) / scaleFactor
                            if (isPixelMode) {
                                dx = (dx / 32f).roundToInt() * 32f
                                dy = (dy / 32f).roundToInt() * 32f
                            }
                            moveDx = dx
                            moveDy = dy
                        }
                        else -> {}
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isDrawing) {
                    val cancelled = event.actionMasked == MotionEvent.ACTION_CANCEL
                    when (currentTool) {
                        Tool.BRUSH, Tool.ERASER -> {
                            saveState()
                        }
                        Tool.LINE, Tool.RECT, Tool.OVAL -> {
                            applyDrawingWithSymmetry(startX, startY, currentX, currentY)
                            saveState()
                        }
                        Tool.TEXT -> {
                            if (!cancelled) onTextPlace?.invoke(currentX, currentY)
                        }
                        Tool.CUT -> {
                            if (!cancelled) {
                                val l = floor(min(startX, currentX)).toInt()
                                val t = floor(min(startY, currentY)).toInt()
                                val rr = ceil(max(startX, currentX)).toInt()
                                val bb = ceil(max(startY, currentY)).toInt()
                                val r = Rect(l, t, rr, bb)
                                if (r.width() >= 3 && r.height() >= 3) {
                                    selRect = RectF(r)
                                    onCutSelected?.invoke(r)
                                } else {
                                    selRect = null
                                }
                            }
                        }
                        Tool.MOVE -> {
                            if (!cancelled) commitMove() else { moveDx = 0f; moveDy = 0f }
                        }
                    }
                    isDrawing = false
                    invalidate()
                }
                isDragging = false
            }
        }
        lastTouchX = rawX
        lastTouchY = rawY
        return true
    }

    // ---------------------------------------------------------------- drawing

    private fun applyDrawingWithSymmetry(x1: Float, y1: Float, x2: Float, y2: Float) {
        if (activeLayerIndex !in layersList.indices) return
        val targetBmp = layersList[activeLayerIndex].bitmap
        val canvas = Canvas(targetBmp)

        val cx = canvasW / 2f
        val cy = canvasH / 2f

        // Execute drawing for primary and mirrored coordinates based on symmetry mode
        val pointsToDraw = mutableListOf<Pair<Pair<Float, Float>, Pair<Float, Float>>>()
        pointsToDraw.add(Pair(Pair(x1, y1), Pair(x2, y2)))

        when (currentSymmetry) {
            1 -> { // Vertical mirror (reflect X across center cx)
                val mx1 = 2 * cx - x1
                val mx2 = 2 * cx - x2
                pointsToDraw.add(Pair(Pair(mx1, y1), Pair(mx2, y2)))
            }
            2 -> { // Horizontal mirror (reflect Y across center cy)
                val my1 = 2 * cy - y1
                val my2 = 2 * cy - y2
                pointsToDraw.add(Pair(Pair(x1, my1), Pair(x2, my2)))
            }
            3 -> { // Four-way mirror
                val mx1 = 2 * cx - x1
                val mx2 = 2 * cx - x2
                val my1 = 2 * cy - y1
                val my2 = 2 * cy - y2
                pointsToDraw.add(Pair(Pair(mx1, y1), Pair(mx2, y2)))
                pointsToDraw.add(Pair(Pair(x1, my1), Pair(x2, my2)))
                pointsToDraw.add(Pair(Pair(mx1, my1), Pair(mx2, my2)))
            }
        }

        for (pt in pointsToDraw) {
            applySingleDrawing(canvas, pt.first.first, pt.first.second, pt.second.first, pt.second.second)
        }
        invalidate()
    }

    private fun applySingleDrawing(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        val drawPaint = Paint(paint).apply {
            if (currentTool == Tool.ERASER) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                color = Color.TRANSPARENT
            } else {
                xfermode = null
                color = brushColor
            }
        }

        if (isPixelMode) {
            val tileSize = 32f
            val gx1 = (x1 / tileSize).toInt()
            val gy1 = (y1 / tileSize).toInt()
            val gx2 = (x2 / tileSize).toInt()
            val gy2 = (y2 / tileSize).toInt()

            when (currentTool) {
                Tool.BRUSH, Tool.ERASER -> drawPixelBresenham(canvas, gx1, gy1, gx2, gy2, tileSize, drawPaint)
                Tool.LINE -> drawPixelBresenham(canvas, gx1, gy1, gx2, gy2, tileSize, drawPaint)
                Tool.RECT -> {
                    val minX = min(gx1, gx2); val maxX = max(gx1, gx2)
                    val minY = min(gy1, gy2); val maxY = max(gy1, gy2)
                    for (gx in minX..maxX) {
                        for (gy in minY..maxY) {
                            if (gx == minX || gx == maxX || gy == minY || gy == maxY) {
                                val p = Paint(drawPaint).apply { style = Paint.Style.FILL }
                                canvas.drawRect(gx * tileSize, gy * tileSize, (gx + 1) * tileSize, (gy + 1) * tileSize, p)
                            }
                        }
                    }
                }
                Tool.OVAL -> {
                    val minX = min(gx1, gx2); val maxX = max(gx1, gx2)
                    val minY = min(gy1, gy2); val maxY = max(gy1, gy2)
                    val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f
                    val rx = (maxX - minX) / 2f; val ry = (maxY - minY) / 2f
                    if (rx > 0 && ry > 0) {
                        for (gx in minX..maxX) {
                            for (gy in minY..maxY) {
                                val dx = (gx - cx) / rx
                                val dy = (gy - cy) / ry
                                if (dx * dx + dy * dy <= 1.0f) {
                                    val p = Paint(drawPaint).apply { style = Paint.Style.FILL }
                                    canvas.drawRect(gx * tileSize, gy * tileSize, (gx + 1) * tileSize, (gy + 1) * tileSize, p)
                                }
                            }
                        }
                    }
                }
                else -> {}
            }
        } else {
            when (currentTool) {
                Tool.BRUSH -> drawBrushStroke(canvas, x1, y1, x2, y2, drawPaint)
                Tool.ERASER -> canvas.drawLine(x1, y1, x2, y2, drawPaint)
                Tool.LINE -> canvas.drawLine(x1, y1, x2, y2, drawPaint)
                Tool.RECT -> canvas.drawRect(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2), drawPaint)
                Tool.OVAL -> canvas.drawOval(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2), drawPaint)
                else -> {}
            }
        }
    }

    /** Berbagai jenis kuas / pena (mode ART BIASA). */
    private fun drawBrushStroke(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, p: Paint) {
        when (brushType) {
            BrushType.KUAS -> canvas.drawLine(x1, y1, x2, y2, p)

            BrushType.PENA -> {
                // Pena tinta: tebal-tipis mengikuti kecepatan jari (atau tekanan stylus)
                val ip = Paint(p).apply { strokeWidth = inkWidth.coerceAtLeast(1f) }
                canvas.drawLine(x1, y1, x2, y2, ip)
            }

            BrushType.KALIGRAFI -> {
                // Ujung pena miring 45 derajat
                val half = brushSize / 2f
                val ox = half * 0.7071f
                val oy = -half * 0.7071f
                val path = Path().apply {
                    moveTo(x1 - ox, y1 - oy)
                    lineTo(x1 + ox, y1 + oy)
                    lineTo(x2 + ox, y2 + oy)
                    lineTo(x2 - ox, y2 - oy)
                    close()
                }
                val fp = Paint(p).apply {
                    style = Paint.Style.FILL_AND_STROKE
                    strokeWidth = 1.5f
                    strokeJoin = Paint.Join.ROUND
                }
                canvas.drawPath(path, fp)
            }

            BrushType.SPIDOL -> {
                // Spidol: ujung kotak
                val mp = Paint(p).apply {
                    strokeCap = Paint.Cap.SQUARE
                    strokeJoin = Paint.Join.MITER
                }
                canvas.drawLine(x1, y1, x2, y2, mp)
            }

            BrushType.PENSIL -> {
                // Pensil: butiran kasar yang menumpuk
                val r = max(brushSize / 2f, 0.5f)
                val dist = hypot(x2 - x1, y2 - y1)
                val step = max(1f, r / 3f)
                val steps = max(1, (dist / step).toInt())
                val gp = Paint(p).apply {
                    style = Paint.Style.FILL
                    alpha = 170
                }
                val dots = max(3, (r * 1.2f).toInt())
                val dotR = max(0.6f, r * 0.12f)
                for (i in 0..steps) {
                    val t = i / steps.toFloat()
                    val px = x1 + (x2 - x1) * t
                    val py = y1 + (y2 - y1) * t
                    for (k in 0 until dots) {
                        val a = rng.nextFloat() * 6.2831855f
                        val d = sqrt(rng.nextFloat()) * r
                        canvas.drawCircle(px + cos(a) * d, py + sin(a) * d, dotR, gp)
                    }
                }
            }

            BrushType.AIRBRUSH -> {
                // Airbrush: cat lembut, makin lama makin pekat
                val r = max(brushSize, 2f)
                val core = Color.argb(38, Color.red(brushColor), Color.green(brushColor), Color.blue(brushColor))
                val edge = Color.argb(0, Color.red(brushColor), Color.green(brushColor), Color.blue(brushColor))
                val grad = RadialGradient(0f, 0f, r, core, edge, Shader.TileMode.CLAMP)
                val ap = Paint(Paint.ANTI_ALIAS_FLAG)
                ap.shader = grad
                val dist = hypot(x2 - x1, y2 - y1)
                val step = max(1f, r / 5f)
                val steps = max(3, (dist / step).toInt())
                for (i in 0..steps) {
                    val t = i / steps.toFloat()
                    canvas.save()
                    canvas.translate(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)
                    canvas.drawCircle(0f, 0f, r, ap)
                    canvas.restore()
                }
            }

            BrushType.SEMPROT -> {
                // Semprot / spray: titik acak
                val r = max(brushSize, 3f)
                val dist = hypot(x2 - x1, y2 - y1)
                val steps = max(1, (dist / (r / 2f)).toInt())
                val sp = Paint(p).apply { style = Paint.Style.FILL }
                val dotR = max(0.7f, r * 0.035f)
                for (i in 0..steps) {
                    val t = i / steps.toFloat()
                    val px = x1 + (x2 - x1) * t
                    val py = y1 + (y2 - y1) * t
                    for (k in 0 until 18) {
                        val a = rng.nextFloat() * 6.2831855f
                        val d = sqrt(rng.nextFloat()) * r
                        canvas.drawCircle(px + cos(a) * d, py + sin(a) * d, dotR, sp)
                    }
                }
            }
        }
    }

    private fun drawPixelBresenham(canvas: Canvas, x0: Int, y0: Int, x1: Int, y1: Int, tileSize: Float, p: Paint) {
        val dx = abs(x1 - x0)
        val dy = abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx - dy

        var cx = x0
        var cy = y0

        val fillPaint = Paint(p).apply { style = Paint.Style.FILL }

        while (true) {
            canvas.drawRect(cx * tileSize, cy * tileSize, (cx + 1) * tileSize, (cy + 1) * tileSize, fillPaint)
            if (cx == x1 && cy == y1) break
            val e2 = 2 * err
            if (e2 > -dy) {
                err -= dy
                cx += sx
            }
            if (e2 < dx) {
                err += dx
                cy += sy
            }
        }
    }

    private fun drawPixelBresenhamPreview(canvas: Canvas, x0: Int, y0: Int, x1: Int, y1: Int, tileSize: Float, p: Paint) {
        val dx = abs(x1 - x0)
        val dy = abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx - dy

        var cx = x0
        var cy = y0

        while (true) {
            canvas.drawRect(cx * tileSize, cy * tileSize, (cx + 1) * tileSize, (cy + 1) * tileSize, p)
            if (cx == x1 && cy == y1) break
            val e2 = 2 * err
            if (e2 > -dy) {
                err -= dy
                cx += sx
            }
            if (e2 < dx) {
                err += dx
                cy += sy
            }
        }
    }
}
