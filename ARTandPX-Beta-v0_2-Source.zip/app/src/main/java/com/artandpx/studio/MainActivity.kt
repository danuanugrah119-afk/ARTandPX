package com.artandpx.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.Stack
import kotlin.math.*

data class ArtLayer(
    var name: String,
    var bitmap: Bitmap,
    var visible: Boolean = true,
    var locked: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var board: DrawingBoard
    private lateinit var status: TextView
    private val layers = mutableListOf<ArtLayer>()
    private var selectedLayer = 0
    private var pixelMode = false
    private var symmetry = 0 // 0: off, 1: vertical, 2: horizontal, 3: four-way
    private var tool = DrawingBoard.Tool.BRUSH
    private var currentColor = Color.BLACK
    private var brushType = DrawingBoard.BrushType.KUAS
    private lateinit var brushBtn: Button

    // Teks
    private data class FontOption(val name: String, val family: String?, val custom: Typeface? = null)
    private val fontOptions = mutableListOf(
        FontOption("Sans (Roboto)", "sans-serif"),
        FontOption("Sans Ramping (Condensed)", "sans-serif-condensed"),
        FontOption("Sans Tebal (Black)", "sans-serif-black"),
        FontOption("Sans Tipis (Light)", "sans-serif-light"),
        FontOption("Serif", "serif"),
        FontOption("Monospace", "monospace"),
        FontOption("Casual", "casual"),
        FontOption("Tulisan Tangan (Cursive)", "cursive")
    )
    private var tText = ""
    private var tSize = 64
    private var tFont = 0
    private var tBold = false
    private var tItalic = false
    private var pendingTextX = 0f
    private var pendingTextY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 17, 22)
        window.navigationBarColor = Color.rgb(16, 17, 22)
        layers.add(ArtLayer("Layer 1", Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888)))
        board = DrawingBoard(this, layers)
        board.onLayersChanged = {
            selectedLayer = board.activeLayerIndex
            if (::status.isInitialized) refreshStatus()
        }
        board.onTextPlace = { x, y -> showTextDialog(x, y) }
        board.onCutSelected = { r -> showCutDialog(r) }
        board.setColor(currentColor)
        buildUi()
    }

    private var toolbarOpen = true
    private lateinit var toolbarPanel: LinearLayout

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 17, 22))
            setPadding(8, 6, 8, 6)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "ARTandPX Beta v0.2"; textSize = 19f; setTextColor(Color.WHITE); setPadding(6, 8, 6, 8)
            setTypeface(null, Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("⌃  TOOLS") { toolbarOpen = !toolbarOpen; toolbarPanel.visibility = if (toolbarOpen) View.VISIBLE else View.GONE })
        root.addView(header)

        val modes = makeRow(
            button("✎  ART BIASA") { pixelMode = false; board.setPixelMode(false); refreshStatus() },
            button("▦  PIXEL ART v0.2") { pixelMode = true; board.setPixelMode(true); refreshStatus() }
        )
        root.addView(modes)
        status = TextView(this).apply {
            text = "ARTandPX Beta v0.2 • 1 layer"; textSize = 12f
            setTextColor(Color.LTGRAY); setPadding(5, 5, 5, 7)
        }
        root.addView(status)

        toolbarPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brushBtn = iconButton("Kuas", "brush") { chooseBrushType() }
        toolbarPanel.addView(makeRow(
            brushBtn,
            iconButton("Eraser", "eraser") { setTool(DrawingBoard.Tool.ERASER) },
            iconButton("Line", "line") { setTool(DrawingBoard.Tool.LINE) },
            iconButton("Rectangle", "rect") { setTool(DrawingBoard.Tool.RECT) },
            iconButton("Oval", "oval") { setTool(DrawingBoard.Tool.OVAL) }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Teks", "text") { setTool(DrawingBoard.Tool.TEXT) },
            iconButton("Potong", "cut") { setTool(DrawingBoard.Tool.CUT) },
            iconButton("Geser", "move") { setTool(DrawingBoard.Tool.MOVE) },
            iconButton("Salin Layer", "copy") { board.duplicateLayer() }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Color", "color") { chooseColor() },
            iconButton("Brush size", "size") { chooseBrushSize() },
            iconButton("Canvas", "canvas") { chooseCanvasSize() },
            iconButton("Mirror", "mirror") { chooseSymmetry() },
            iconButton("Layers", "layers") { showLayers() },
            iconButton("Undo", "undo") { board.undo() },
            iconButton("Redo", "redo") { board.redo() }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Import", "import") {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
                startActivityForResult(intent, 410)
            },
            iconButton("Export", "export") { showExportDialog() },
            iconButton("Clear", "clear") { confirmClear() }
        ))
        toolbarPanel.addView(makeRow(
            iconButton("Zoom +", "zoom_in") { board.zoomBy(1.25f) },
            iconButton("Zoom −", "zoom_out") { board.zoomBy(0.8f) },
            iconButton("Reset", "reset") { board.resetView() }
        ))
        val toolbarScroll = MaxHeightScrollView(this, (resources.displayMetrics.heightPixels * 0.4f).toInt()).apply {
            isVerticalScrollBarEnabled = false
            addView(toolbarPanel)
        }
        root.addView(toolbarScroll)

        val canvasFrame = FrameLayout(this).apply { setBackgroundColor(Color.rgb(37, 38, 45)) }
        canvasFrame.addView(board, FrameLayout.LayoutParams(-1, -1))
        root.addView(canvasFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val palette = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 4) }
        val colors = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW,
            Color.CYAN, Color.MAGENTA, Color.rgb(255, 128, 0), Color.rgb(128, 80, 220))
        colors.forEach { c ->
            val swatch = View(this).apply {
                setBackgroundColor(c)
                setOnClickListener { currentColor = c; board.setColor(c); refreshStatus() }
            }
            palette.addView(swatch, LinearLayout.LayoutParams(0, 32, 1f).apply { setMargins(3, 0, 3, 0) })
        }
        root.addView(palette)
        setContentView(root)
        refreshStatus()
    }

    private fun makeRow(vararg views: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 3, 0, 3)
            views.forEach { addView(it, LinearLayout.LayoutParams(0, (resources.displayMetrics.density * 62).toInt(), 1f).apply {
                setMargins(2, 0, 2, 0)
            }) }
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48, 49, 61))
            setOnClickListener { action() }
        }

    private fun iconButton(label: String, kind: String, action: () -> Unit): Button {
        val size = (resources.displayMetrics.density * 24).toInt().coerceAtLeast(24)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = size * .09f
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val f = size.toFloat(); val mid = f / 2f
        when (kind) {
            "brush" -> { c.drawLine(f*.22f,f*.78f,f*.72f,f*.28f,p); c.drawLine(f*.62f,f*.18f,f*.82f,f*.38f,p); c.drawOval(f*.12f,f*.68f,f*.35f,f*.9f,p) }
            "eraser" -> { val path = Path().apply { moveTo(f*.25f,f*.65f); lineTo(f*.55f,f*.2f); lineTo(f*.86f,f*.5f); lineTo(f*.56f,f*.85f); close() }; c.drawPath(path,p); c.drawLine(f*.43f,f*.72f,f*.7f,f*.72f,p) }
            "line" -> c.drawLine(f*.18f,f*.82f,f*.82f,f*.18f,p)
            "rect" -> c.drawRect(f*.18f,f*.2f,f*.82f,f*.8f,p)
            "oval" -> c.drawOval(f*.16f,f*.25f,f*.84f,f*.75f,p)
            "color" -> { c.drawCircle(mid,mid,f*.3f,p); c.drawCircle(mid,mid,f*.1f,p) }
            "size" -> { c.drawLine(f*.18f,f*.5f,f*.82f,f*.5f,p); c.drawCircle(f*.5f,f*.5f,f*.2f,p) }
            "canvas" -> { c.drawRect(f*.18f,f*.18f,f*.82f,f*.82f,p); c.drawLine(f*.18f,f*.4f,f*.82f,f*.4f,p) }
            "mirror" -> { c.drawLine(mid,f*.15f,mid,f*.85f,p); c.drawLine(f*.12f,f*.5f,f*.42f,f*.25f,p); c.drawLine(f*.12f,f*.5f,f*.42f,f*.75f,p); c.drawLine(f*.88f,f*.5f,f*.58f,f*.25f,p); c.drawLine(f*.88f,f*.5f,f*.58f,f*.75f,p) }
            "layers" -> { c.drawLine(f*.5f,f*.15f,f*.88f,f*.38f,p); c.drawLine(f*.88f,f*.38f,f*.5f,f*.6f,p); c.drawLine(f*.5f,f*.6f,f*.12f,f*.38f,p); c.drawLine(f*.12f,f*.38f,f*.5f,f*.15f,p); c.drawLine(f*.18f,f*.58f,f*.5f,f*.78f,p); c.drawLine(f*.5f,f*.78f,f*.82f,f*.58f,p) }
            "undo" -> { c.drawArc(f*.25f,f*.25f,f*.82f,f*.82f,200f,230f,false,p); c.drawLine(f*.15f,f*.25f,f*.15f,f*.52f,p); c.drawLine(f*.15f,f*.25f,f*.42f,f*.25f,p) }
            "redo" -> { c.drawArc(f*.18f,f*.25f,f*.75f,f*.82f,110f,230f,false,p); c.drawLine(f*.85f,f*.25f,f*.85f,f*.52f,p); c.drawLine(f*.85f,f*.25f,f*.58f,f*.25f,p) }
            "import" -> { c.drawRect(f*.15f,f*.38f,f*.85f,f*.82f,p); c.drawLine(mid,f*.12f,mid,f*.58f,p); c.drawLine(f*.32f,f*.32f,mid,f*.12f,p); c.drawLine(f*.68f,f*.32f,mid,f*.12f,p) }
            "export" -> { c.drawRect(f*.15f,f*.48f,f*.85f,f*.85f,p); c.drawLine(mid,f*.12f,mid,f*.62f,p); c.drawLine(f*.32f,f*.42f,mid,f*.62f,p); c.drawLine(f*.68f,f*.42f,mid,f*.62f,p) }
            "clear" -> { c.drawRect(f*.25f,f*.3f,f*.75f,f*.82f,p); c.drawLine(f*.18f,f*.22f,f*.82f,f*.22f,p) }
            "zoom_in" -> { c.drawCircle(f*.42f,f*.42f,f*.25f,p); c.drawLine(f*.6f,f*.6f,f*.85f,f*.85f,p); c.drawLine(f*.42f,f*.3f,f*.42f,f*.54f,p); c.drawLine(f*.3f,f*.42f,f*.54f,f*.42f,p) }
            "zoom_out" -> { c.drawCircle(f*.42f,f*.42f,f*.25f,p); c.drawLine(f*.6f,f*.6f,f*.85f,f*.85f,p); c.drawLine(f*.3f,f*.42f,f*.54f,f*.42f,p) }
            "text" -> { c.drawLine(f*.2f,f*.22f,f*.8f,f*.22f,p); c.drawLine(mid,f*.22f,mid,f*.82f,p); c.drawLine(f*.38f,f*.82f,f*.62f,f*.82f,p) }
            "cut" -> { c.drawCircle(f*.28f,f*.78f,f*.11f,p); c.drawCircle(f*.72f,f*.78f,f*.11f,p); c.drawLine(f*.33f,f*.68f,f*.72f,f*.15f,p); c.drawLine(f*.67f,f*.68f,f*.28f,f*.15f,p) }
            "move" -> {
                c.drawLine(mid,f*.15f,mid,f*.85f,p); c.drawLine(f*.15f,mid,f*.85f,mid,p)
                c.drawLine(f*.38f,f*.3f,mid,f*.15f,p); c.drawLine(f*.62f,f*.3f,mid,f*.15f,p)
                c.drawLine(f*.38f,f*.7f,mid,f*.85f,p); c.drawLine(f*.62f,f*.7f,mid,f*.85f,p)
                c.drawLine(f*.3f,f*.38f,f*.15f,mid,p); c.drawLine(f*.3f,f*.62f,f*.15f,mid,p)
                c.drawLine(f*.7f,f*.38f,f*.85f,mid,p); c.drawLine(f*.7f,f*.62f,f*.85f,mid,p)
            }
            "copy" -> { c.drawRect(f*.32f,f*.3f,f*.84f,f*.86f,p); c.drawLine(f*.16f,f*.68f,f*.16f,f*.14f,p); c.drawLine(f*.16f,f*.14f,f*.62f,f*.14f,p) }
            else -> c.drawCircle(mid, mid, f*.28f, p)
        }
        val drawable = BitmapDrawable(resources, bmp).apply { setBounds(0, 0, size, size) }
        return Button(this).apply {
            text = label; textSize = 9f; isAllCaps = false; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(48, 49, 61))
            setCompoundDrawables(null, drawable, null, null); compoundDrawablePadding = 1
            setPadding(1, 2, 1, 2); setOnClickListener { action() }
        }
    }

    private fun setTool(t: DrawingBoard.Tool) {
        tool = t; board.setTool(t)
        val msg = when (t) {
            DrawingBoard.Tool.TEXT -> "Teks: tap / seret lalu lepas di titik tengah teks"
            DrawingBoard.Tool.CUT -> "Potong: tarik untuk memilih area (di layer aktif)"
            DrawingBoard.Tool.MOVE -> "Geser: seret untuk memindah isi layer aktif"
            else -> "${t.name.lowercase()} tool"
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun chooseSymmetry() {
        val options = arrayOf("Off (No mirror)", "Vertical mirror", "Horizontal mirror", "Four-way mirror")
        AlertDialog.Builder(this).setTitle("Mirror / Symmetry")
            .setSingleChoiceItems(options, symmetry) { d, which ->
                symmetry = which; board.setSymmetry(which); d.dismiss(); refreshStatus()
                Toast.makeText(this, "Mirror: ${options[which]}", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun symmetryName() = arrayOf("Mirror off", "Vertical mirror", "Horizontal mirror", "Four-way")[symmetry]

    private fun chooseColor() {
        val wheel = ColorWheelView(this).apply { setColor(currentColor) }
        val hex = EditText(this).apply {
            hint = "#RRGGBB"; setSingleLine(true)
            setText(String.format("#%06X", 0xFFFFFF and currentColor))
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 4)
            addView(wheel, LinearLayout.LayoutParams(-1, 240))
            addView(hex)
        }
        val dialog = AlertDialog.Builder(this).setTitle("Roda Warna & Kode HEX")
            .setView(wrap)
            .setPositiveButton("Pakai Warna", null)
            .setNegativeButton("Batal", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                try {
                    currentColor = if (hex.text.isNullOrBlank()) wheel.selectedColor
                    else Color.parseColor(if (hex.text.toString().trim().startsWith("#")) hex.text.toString().trim() else "#" + hex.text.toString().trim())
                    board.setColor(currentColor); refreshStatus(); dialog.dismiss()
                } catch (_: Exception) {
                    hex.error = "Gunakan format #RRGGBB"
                }
            }
        }
        wheel.onColorChanged = { c -> hex.setText(String.format("#%06X", 0xFFFFFF and c)) }
        dialog.show()
    }

    private fun chooseBrushSize() {
        val seek = SeekBar(this).apply { max = 199; progress = 7 }
        val value = TextView(this).apply { text = "Ukuran kuas: 8 px"; setPadding(12, 8, 12, 8) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                val size = p + 1; value.text = "Ukuran kuas: $size px"; board.setBrushSize(size.toFloat())
            }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 4); addView(value); addView(seek) }.also { box ->
            AlertDialog.Builder(this).setTitle("Ukuran Kuas (1–200 px)").setView(box).setPositiveButton("Selesai", null).show()
        }
    }

    private fun chooseCanvasSize() {
        val sizes = arrayOf("128 × 128", "256 × 256", "512 × 512", "1024 × 1024", "2048 × 2048",
            "📜 Webtoon / Manhwa (panjang ke bawah)…", "Ukuran bebas (custom)…")
        val values = intArrayOf(128, 256, 512, 1024, 2048)
        AlertDialog.Builder(this).setTitle("Ukuran Kanvas (Clear Drawing)")
            .setItems(sizes) { _, which ->
                when {
                    which < values.size -> applyCanvasSize(values[which], values[which])
                    which == values.size -> chooseWebtoonSize()
                    else -> askCustomCanvasSize(1024, 1024)
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun chooseWebtoonSize() {
        val sizes = arrayOf("800 × 3.000 (pendek)", "800 × 6.000 (sedang)", "800 × 10.000 (panjang)", "Atur sendiri (lebar × tinggi)…")
        val heights = intArrayOf(3000, 6000, 10000)
        AlertDialog.Builder(this).setTitle("Kanvas Webtoon / Manhwa")
            .setItems(sizes) { _, which ->
                if (which < heights.size) applyCanvasSize(800, heights[which]) else askCustomCanvasSize(800, 6000)
            }.setNegativeButton("Kembali") { _, _ -> chooseCanvasSize() }.show()
    }

    private fun askCustomCanvasSize(defW: Int, defH: Int) {
        val wEdit = EditText(this).apply {
            hint = "Lebar (px)"; inputType = InputType.TYPE_CLASS_NUMBER; setText(defW.toString())
        }
        val hEdit = EditText(this).apply {
            hint = "Tinggi (px)"; inputType = InputType.TYPE_CLASS_NUMBER; setText(defH.toString())
        }
        val info = TextView(this).apply { text = "Lebar 64–4096 px, tinggi 64–20000 px (maks 16 juta piksel)" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 4)
            addView(info); addView(wEdit); addView(hEdit)
        }
        AlertDialog.Builder(this).setTitle("Ukuran Kanvas Bebas").setView(box)
            .setPositiveButton("Buat") { _, _ ->
                val w = wEdit.text.toString().trim().toIntOrNull()
                val h = hEdit.text.toString().trim().toIntOrNull()
                if (w == null || h == null) {
                    Toast.makeText(this, "Isi lebar dan tinggi dengan angka", Toast.LENGTH_SHORT).show()
                } else {
                    applyCanvasSize(w, h)
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun applyCanvasSize(w: Int, h: Int) {
        if (w !in 64..4096 || h !in 64..20000 || w.toLong() * h.toLong() > 16000000L) {
            Toast.makeText(this, "Ukuran tidak valid (lebar 64–4096, tinggi 64–20000, maks 16 juta piksel)", Toast.LENGTH_LONG).show()
            return
        }
        if (board.resizeCanvas(w, h)) {
            refreshStatus()
            Toast.makeText(this, "Kanvas baru $w × $h px (direset bersih)", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseBrushType() {
        val types = DrawingBoard.BrushType.values()
        val labels = arrayOf(
            "Kuas (bulat, standar)",
            "Pena tinta (tebal-tipis ikut kecepatan / tekanan stylus)",
            "Pena kaligrafi (ujung miring)",
            "Spidol (ujung kotak)",
            "Pensil (berbutir)",
            "Airbrush (lembut, menumpuk)",
            "Semprot / spray"
        )
        AlertDialog.Builder(this).setTitle("Jenis Brush / Pena")
            .setSingleChoiceItems(labels, types.indexOf(brushType)) { d, which ->
                brushType = types[which]
                board.setBrushType(brushType)
                brushBtn.text = brushType.label
                setTool(DrawingBoard.Tool.BRUSH)
                d.dismiss()
                Toast.makeText(this, "${brushType.label} aktif (jenis ini hanya untuk mode ART BIASA)", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun showLayers() {
        val names = layers.mapIndexed { i, l ->
            "${if (i == board.activeLayerIndex) "▶ " else ""}${if (l.visible) "◉" else "○"}${if (l.locked) " 🔒 " else "  "}${l.name}"
        }.toMutableList()
        names.add("＋ Add new layer")
        AlertDialog.Builder(this).setTitle("Layers (v0.2)")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == layers.size) {
                    board.addLayer("Layer ${layers.size + 1}")
                    showLayerActions(board.activeLayerIndex)
                } else {
                    selectedLayer = which
                    board.selectLayer(which)
                    showLayerActions(which)
                }
                refreshStatus()
            }.setNegativeButton("Close", null).show()
    }

    private fun showLayerActions(index: Int) {
        val layer = layers[index]
        val actions = arrayOf(
            "Rename", if (layer.visible) "Hide layer" else "Show layer",
            if (layer.locked) "Unlock layer" else "Lock layer",
            "Salin layer (duplikat)", "Potong (pilih area)", "Delete layer"
        )
        AlertDialog.Builder(this).setTitle(layer.name).setItems(actions) { _, choice ->
            when (choice) {
                0 -> {
                    val edit = EditText(this).apply { setText(layer.name) }
                    AlertDialog.Builder(this).setTitle("Rename layer").setView(edit)
                        .setPositiveButton("Save") { _, _ ->
                            layer.name = edit.text.toString().ifBlank { layer.name }
                            showLayers()
                        }.setNegativeButton("Cancel", null).show()
                }
                1 -> { layer.visible = !layer.visible; board.invalidate(); showLayers() }
                2 -> { layer.locked = !layer.locked; showLayers() }
                3 -> { board.duplicateLayer(index); showLayers() }
                4 -> { board.selectLayer(index); selectedLayer = index; setTool(DrawingBoard.Tool.CUT) }
                5 -> if (layers.size > 1) {
                    board.deleteLayer(index); showLayers()
                } else Toast.makeText(this, "Minimal harus ada satu layer", Toast.LENGTH_SHORT).show()
            }
        }.setNegativeButton("Back") { _, _ -> showLayers() }.show()
    }

    @Deprecated("Legacy activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 411) {
            // Pilih font sendiri -> setelah selesai (atau batal) buka lagi dialog teks
            val fontUri = data?.data
            if (resultCode == RESULT_OK && fontUri != null) loadCustomFont(fontUri)
            else showTextDialog(pendingTextX, pendingTextY)
            return
        }
        if (requestCode == 410 && resultCode == RESULT_OK) data?.data?.let { addImportedLayer(it) }
    }

    private fun addImportedLayer(uri: Uri) {
        try {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw Exception("Gambar tidak terbaca")
            val cw = board.canvasW
            val ch = board.canvasH
            val tall = ch > cw * 1.5f
            val target = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
            val c = Canvas(target)
            // Kanvas webtoon: lebar gambar pas lebar kanvas, ditaruh di bagian yang sedang terlihat
            val scale = if (tall) cw.toFloat() / bmp.width
                        else min(cw.toFloat() / bmp.width, ch.toFloat() / bmp.height)
            val w = bmp.width * scale
            val h = bmp.height * scale
            val left = (cw - w) / 2
            val top = if (tall) min(board.visibleTopY(), max(0f, ch - h)) else (ch - h) / 2
            val dst = RectF(left, top, left + w, top + h)
            c.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            board.addLayerWithBitmap("Imported ${layers.size}", target)
            Toast.makeText(this, "Gambar masuk sebagai layer baru (pakai alat Geser untuk memindah)", Toast.LENGTH_SHORT).show()
            refreshStatus()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal import: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------------ TEKS

    private fun typefaceFor(opt: FontOption, bold: Boolean, italic: Boolean): Typeface {
        val style = when {
            bold && italic -> Typeface.BOLD_ITALIC
            bold -> Typeface.BOLD
            italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        val custom = opt.custom
        return if (custom != null) Typeface.create(custom, style) else Typeface.create(opt.family, style)
    }

    private fun showTextDialog(x: Float, y: Float) {
        pendingTextX = x; pendingTextY = y
        val density = resources.displayMetrics.density

        val preview = TextView(this).apply {
            setBackgroundColor(Color.rgb(190, 190, 196)); gravity = Gravity.CENTER
            setPadding(12, 16, 12, 16); minHeight = (density * 70).toInt(); maxLines = 4
        }
        val edit = EditText(this).apply {
            hint = "Ketik teks di sini…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 2; gravity = Gravity.TOP or Gravity.START
            setText(tText); setSelection(text.length)
        }
        if (tFont !in fontOptions.indices) tFont = 0
        val fontSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, fontOptions.map { it.name })
            setSelection(tFont)
        }
        val bold = CheckBox(this).apply { text = "Tebal"; isChecked = tBold }
        val italic = CheckBox(this).apply { text = "Miring"; isChecked = tItalic }
        val sizeLabel = TextView(this)
        val seek = SeekBar(this).apply { max = 392; progress = (tSize - 8).coerceIn(0, 392) }

        fun refresh() {
            val opt = fontOptions[tFont.coerceIn(0, fontOptions.size - 1)]
            preview.typeface = typefaceFor(opt, tBold, tItalic)
            preview.setTextColor(currentColor)
            preview.setTextSize(TypedValue.COMPLEX_UNIT_PX, (tSize * 0.5f).coerceIn(14f, 60f) * density)
            preview.text = if (tText.isBlank()) "Contoh teks Abc 123" else tText
            sizeLabel.text = "Ukuran huruf: $tSize px"
        }

        edit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { tText = s?.toString() ?: ""; refresh() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        fontSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) { tFont = pos; refresh() }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        bold.setOnCheckedChangeListener { _, checked -> tBold = checked; refresh() }
        italic.setOnCheckedChangeListener { _, checked -> tItalic = checked; refresh() }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) { tSize = p + 8; refresh() }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })

        val style = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(bold); addView(italic)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 4)
            addView(preview, LinearLayout.LayoutParams(-1, -2))
            addView(edit)
            addView(fontSpinner)
            addView(style)
            addView(sizeLabel)
            addView(seek)
        }
        val scroll = ScrollView(this).apply { addView(box) }
        refresh()

        AlertDialog.Builder(this).setTitle("Teks (titik tengah = tempat kamu lepas jari)")
            .setView(scroll)
            .setPositiveButton("Tulis") { _, _ ->
                if (tText.isBlank()) {
                    Toast.makeText(this, "Teks masih kosong", Toast.LENGTH_SHORT).show()
                } else {
                    val opt = fontOptions[tFont.coerceIn(0, fontOptions.size - 1)]
                    board.drawTextAt(tText, pendingTextX, pendingTextY, typefaceFor(opt, tBold, tItalic), tSize.toFloat(), currentColor)
                }
            }
            .setNeutralButton("Font sendiri…") { _, _ -> pickCustomFont() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun pickCustomFont() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(intent, 411)
    }

    private fun loadCustomFont(uri: Uri) {
        try {
            val name = contentResolver.query(uri, null, null, null, null)?.use { cur ->
                val idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cur.moveToFirst()) cur.getString(idx) else null
            } ?: "Font sendiri"
            val file = File(cacheDir, "font_${System.currentTimeMillis()}.ttf")
            val input = contentResolver.openInputStream(uri) ?: throw Exception("File tidak terbaca")
            input.use { ins -> FileOutputStream(file).use { out -> ins.copyTo(out) } }
            val tf = Typeface.createFromFile(file)
            fontOptions.add(FontOption("★ " + name.substringBeforeLast('.'), null, tf))
            tFont = fontOptions.lastIndex
            Toast.makeText(this, "Font dimuat: $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Font gagal dimuat: ${e.message}", Toast.LENGTH_LONG).show()
        }
        showTextDialog(pendingTextX, pendingTextY)
    }

    // ---------------------------------------------------------------- POTONG

    private fun showCutDialog(r: Rect) {
        val opts = arrayOf(
            "✂ Potong ke layer baru (area dipindah)",
            "🗑 Potong & hapus area ini",
            "▣ Crop: sisakan area ini saja"
        )
        AlertDialog.Builder(this).setTitle("Potong area ${r.width()} × ${r.height()} px")
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> board.cutRegion(r, true)
                    1 -> board.cutRegion(r, false)
                    else -> board.cropToRegion(r)
                }
            }
            .setNegativeButton("Batal", null)
            .setOnDismissListener { board.clearSelection() }
            .show()
    }

    // ---------------------------------------------------------------- EXPORT

    private fun showExportDialog() {
        val options = arrayOf("Background Putih (White)", "Background Hijau (Green)", "Background Transparan (Transparent)")
        AlertDialog.Builder(this)
            .setTitle("Pilih Background Ekspor (v0.2)")
            .setItems(options) { _, which ->
                val bg = when (which) {
                    0 -> Color.WHITE
                    1 -> Color.GREEN
                    else -> Color.TRANSPARENT
                }
                if (board.canvasH > board.canvasW * 1.5f) askExportMode(bg) else exportPng(bg, false)
            }
            .show()
    }

    private fun askExportMode(bg: Int) {
        val opts = arrayOf("Satu file panjang", "Potong per 1280 px (siap upload Webtoon)")
        AlertDialog.Builder(this).setTitle("Mode Ekspor Webtoon")
            .setItems(opts) { _, which -> exportPng(bg, which == 1) }
            .setNegativeButton("Batal", null).show()
    }

    private fun savePng(bmp: Bitmap, filename: String) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ARTandPX-Beta-v02")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Tidak bisa membuat file")
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, filename)
            val fos = FileOutputStream(file)
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
            fos.flush()
            fos.close()
        }
    }

    private fun exportPng(bgColor: Int, sliced: Boolean) {
        try {
            val merged = Bitmap.createBitmap(board.canvasW, board.canvasH, Bitmap.Config.ARGB_8888)
            val c = Canvas(merged)
            c.drawColor(bgColor)
            layers.filter { it.visible }.forEach { c.drawBitmap(it.bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG)) }

            val stamp = System.currentTimeMillis()
            if (!sliced) {
                savePng(merged, "ARTandPX_v0.2_$stamp.png")
                Toast.makeText(this, "PNG tersimpan di Pictures/ARTandPX-Beta-v02", Toast.LENGTH_LONG).show()
            } else {
                var y = 0
                var n = 1
                while (y < merged.height) {
                    val h = min(1280, merged.height - y)
                    val part = Bitmap.createBitmap(merged, 0, y, merged.width, h)
                    val num = String.format("%02d", n)
                    savePng(part, "ARTandPX_v0.2_${stamp}_$num.png")
                    y += h
                    n++
                }
                Toast.makeText(this, "${n - 1} file PNG tersimpan di Pictures/ARTandPX-Beta-v02", Toast.LENGTH_LONG).show()
            }
        } catch (e: OutOfMemoryError) {
            Toast.makeText(this, "Export gagal: memori tidak cukup", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setMessage("Hapus isi layer aktif?")
            .setPositiveButton("Hapus") { _, _ -> board.clearCurrent() }
            .setNegativeButton("Batal", null).show()
    }

    private fun refreshStatus() {
        status.text = "${if (pixelMode) "PIXEL ART v0.2" else "ART BIASA"} • ${layers.size} layer • ${board.canvasW}×${board.canvasH} • ${symmetryName()}"
    }
}

class ColorWheelView(context: Context) : View(context) {
    var selectedColor: Int = Color.RED
        private set
    var onColorChanged: ((Int) -> Unit)? = null
    private val wheelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE }
    private var cx = 0f; private var cy = 0f; private var radius = 0f
    private val colors = IntArray(361) { i -> Color.HSVToColor(floatArrayOf(i.toFloat(), 1f, 1f)) }

    fun setColor(c: Int) { selectedColor = c; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        cx = width / 2f; cy = height / 2f; radius = min(width, height) * .43f
        for (i in 0 until 360) {
            wheelPaint.color = colors[i]
            canvas.drawArc(cx - radius, cy - radius, cx + radius, cy + radius, i.toFloat(), 1f, true, wheelPaint)
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(selectedColor, hsv)
        val angle = hsv[0]
        val r = radius * hsv[1]
        val rad = Math.toRadians(angle.toDouble())
        val mx = cx + (r * cos(rad)).toFloat()
        val my = cy + (r * sin(rad)).toFloat()
        canvas.drawCircle(mx, my, 16f, markerPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            val angle = ((Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())) + 360) % 360).toFloat()
            val sat = (dist / radius).coerceIn(0f, 1f)
            selectedColor = Color.HSVToColor(floatArrayOf(angle, sat, 1f))
            onColorChanged?.invoke(selectedColor)
            invalidate()
            return true
        }
        return super.onTouchEvent(event)
    }
}

class MaxHeightScrollView(context: Context, private val maxPx: Int) : ScrollView(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxPx, View.MeasureSpec.AT_MOST))
    }
}
