# ARTandPX (Beta v0.2)
A polished custom Android drawing and pixel art studio app with pinch-to-zoom, symmetry/mirror, live shape preview, solid pixel fill, and stable undo/redo.

## Fitur tambahan
- **Salin layer** (duplikat layer / gambar import): tombol "Salin Layer" atau menu Layers > Salin layer.
- **Potong**: tarik kotak di layer aktif, lalu pilih potong ke layer baru / potong & hapus / crop.
- **Geser**: pindahkan isi layer aktif (berguna untuk gambar import dan hasil potong).
- **Teks**: ketik langsung, pilih font (bawaan atau file .ttf/.otf sendiri), tebal/miring, ukuran.
- **Jenis brush**: Kuas, Pena tinta, Kaligrafi, Spidol, Pensil, Airbrush, Semprot.
- **Kanvas Webtoon/Manhwa**: panjang vertikal (800 x 3000 / 6000 / 10000 atau ukuran bebas), export bisa dipotong per 1280 px.

