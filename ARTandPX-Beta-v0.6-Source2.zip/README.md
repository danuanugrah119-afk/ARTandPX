# ARTandPX (Beta v0.6)
Ultimate custom Android drawing studio featuring Custom Canvas (Square & Custom sizing working seamlessly in both Normal Art and Pixel Art modes), Advanced Brush Types (Pena, Pensil, Airbrush/Spray, Marker), Movable Text Dialog with Font Family selection, Crop, Mirror/Symmetry, Layers, and Undo/Redo.
