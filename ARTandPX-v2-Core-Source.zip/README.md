# ARTandPX 2.0 Core

Android drawing app source project. Offline-first; no account or server required.

## Included in this core build
- Normal drawing and pixel mode (pixel mode uses a 256x256 drawing surface)
- Multiple bitmap layers: add, select, rename, delete, visibility, lock
- Vertical, horizontal and four-way symmetry
- Brush, eraser, line, rectangle and ellipse
- Undo and redo for drawing strokes
- Import PNG/JPG as a new layer
- Export merged artwork to PNG
- HEX color entry and quick color palette

## Build
Open this folder in Android Studio, or push the files to GitHub and run the
`Build ARTandPX APK` workflow. Requires JDK 17 and Android Gradle Plugin 8.7.3.

## Not yet included
Color wheel/eyedropper, advanced geometry instruments (ruler/protractor/compass),
project archive save/open, custom canvas dimensions and advanced perspective guides.
These are not represented as working controls in this core release.
