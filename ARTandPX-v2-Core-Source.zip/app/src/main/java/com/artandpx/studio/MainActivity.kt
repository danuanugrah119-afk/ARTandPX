package com.artandpx.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import kotlin.math.*

data class ArtLayer(
    var name: String,
    val bitmap: Bitmap,
    var visible: Boolean = true,
    var locked: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var board: DrawingBoard
    private lateinit var status: TextView
    private val layers = mutableListOf<ArtLayer>()
    private var selectedLayer = 0
    private var pixelMode = false
    private var symmetry = 0 // 0 off, 1 vertical, 2 horizontal, 3 four-way
    private var tool = DrawingBoard.Tool.BRUSH
    private var currentColor = Color.BLACK


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,17,22)
        window.navigationBarColor = Color.rgb(16,17,22)
        layers.add(ArtLayer("Layer 1", Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888)))
        board = DrawingBoard(this, layers)
        board.setColor(currentColor)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16,17,22))
            setPadding(10, 8, 10, 8)
        }
        val title = TextView(this).apply {
            text = "ARTandPX  •  STUDIO"
            textSize = 18f; setTextColor(Color.WHITE); setPadding(4, 8, 4, 8)
        }
        root.addView(title)
        status = TextView(this).apply {
            text = "NORMAL • 1 layer"; textSize = 12f
            setTextColor(Color.LTGRAY); setPadding(4, 2, 4, 8)
        }
        root.addView(status)

        val canvasFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(37,38,45))
        }
        canvasFrame.addView(board, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        root.addView(canvasFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(makeRow(
            button("Brush") { setTool(DrawingBoard.Tool.BRUSH) },
            button("Eraser") { setTool(DrawingBoard.Tool.ERASER) },
            button("Line") { setTool(DrawingBoard.Tool.LINE) },
            button("Rect") { setTool(DrawingBoard.Tool.RECT) },
            button("Oval") { setTool(DrawingBoard.Tool.OVAL) }
        ))
        root.addView(makeRow(
            button(if (pixelMode) "Pixel: ON" else "Pixel: OFF") {
                pixelMode = !pixelMode
                board.setPixelMode(pixelMode); refreshStatus(); buildUiRefresh()
            },
            button("Mirror") { chooseSymmetry() },
            button("Undo") { board.undo() },
            button("Redo") { board.redo() },
            button("Layers") { showLayers() }
        ))
        root.addView(makeRow(
            button("Color") { chooseColor() },
            button("Import") {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
                }
                startActivityForResult(intent, 410)
            },
            button("Export PNG") { exportPng() },
            button("Clear") { confirmClear() }
        ))
        val palette = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 6, 0, 4)
        }
        val colors = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE,
            Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.rgb(255,128,0), Color.rgb(128,80,220))
        colors.forEach { c ->
            val swatch = View(this).apply {
                setBackgroundColor(c)
                setOnClickListener { currentColor = c; board.setColor(c); refreshStatus() }
            }
            palette.addView(swatch, LinearLayout.LayoutParams(0, 34, 1f).apply {
                setMargins(3, 0, 3, 0)
            })
        }
        root.addView(palette)
        setContentView(root)
        refreshStatus()
    }

    private fun buildUiRefresh() {
        // Refresh labels while preserving the existing drawing board.
        status.text = "${if (pixelMode) "PIXEL ART" else "NORMAL"} • ${layers.size} layer • ${symmetryName()}"
    }

    private fun makeRow(vararg views: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 3, 0, 3)
            views.forEach { addView(it, LinearLayout.LayoutParams(0, 44, 1f).apply {
                setMargins(2, 0, 2, 0)
            }) }
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48,49,61))
            setOnClickListener { action() }
        }

    private fun setTool(t: DrawingBoard.Tool) {
        tool = t; board.setTool(t)
        Toast.makeText(this, "${t.name.lowercase()} tool", Toast.LENGTH_SHORT).show()
    }

    private fun chooseSymmetry() {
        val options = arrayOf("Off", "Vertical mirror", "Horizontal mirror", "Four-way")
        AlertDialog.Builder(this).setTitle("Symmetry")
            .setSingleChoiceItems(options, symmetry) { d, which ->
                symmetry = which; board.setSymmetry(which); d.dismiss(); refreshStatus()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun symmetryName() = arrayOf("Mirror off", "Vertical", "Horizontal", "Four-way")[symmetry]

    private fun chooseColor() {
        val input = EditText(this).apply {
            hint = "#RRGGBB"; setSingleLine(true)
            setText(String.format("#%06X", 0xFFFFFF and currentColor))
        }
        AlertDialog.Builder(this).setTitle("HEX color").setView(input)
            .setPositiveButton("Apply") { _, _ ->
                try {
                    currentColor = Color.parseColor(input.text.toString().trim())
                    board.setColor(currentColor); refreshStatus()
                } catch (_: Exception) {
                    Toast.makeText(this, "Format warna salah. Contoh: #FF8800", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showLayers() {
        val names = layers.mapIndexed { i, l ->
            "${if (i == selectedLayer) "▶ " else ""}${if (l.visible) "◉" else "○"}${if (l.locked) " 🔒 " else "  "}${l.name}"
        }.toMutableList()
        names.add("＋ Add new layer")
        AlertDialog.Builder(this).setTitle("Layers")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == layers.size) {
                    layers.add(ArtLayer("Layer ${layers.size + 1}", Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)))
                    selectedLayer = layers.lastIndex
                    board.setLayers(layers, selectedLayer)
                    showLayerActions(selectedLayer)
                } else {
                    selectedLayer = which
                    board.setLayers(layers, selectedLayer)
                    showLayerActions(which)
                }
                refreshStatus()
            }.setNegativeButton("Close", null).show()
    }

    private fun showLayerActions(index: Int) {
        val layer = layers[index]
        val actions = arrayOf(
            "Rename", if (layer.visible) "Hide layer" else "Show layer",
            if (layer.locked) "Unlock layer" else "Lock layer", "Delete layer"
        )
        AlertDialog.Builder(this).setTitle(layer.name).setItems(actions) { _, choice ->
            when (choice) {
                0 -> {
                    val edit = EditText(this).apply { setText(layer.name) }
                    AlertDialog.Builder(this).setTitle("Rename layer").setView(edit)
                        .setPositiveButton("Save") { _, _ ->
                            layer.name = edit.text.toString().ifBlank { layer.name }
                            showLayers()
                        }.setNegativeButton("Cancel", null).show()
                }
                1 -> { layer.visible = !layer.visible; board.invalidate(); showLayers() }
                2 -> { layer.locked = !layer.locked; showLayers() }
                3 -> if (layers.size > 1) {
                    layers.removeAt(index); selectedLayer = (selectedLayer - 1).coerceAtLeast(0)
                    board.setLayers(layers, selectedLayer); showLayers()
                } else Toast.makeText(this, "Minimal harus ada satu layer", Toast.LENGTH_SHORT).show()
            }
        }.setNegativeButton("Back") { _, _ -> showLayers() }.show()
    }

    @Deprecated("Legacy activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 410 && resultCode == RESULT_OK) data?.data?.let { addImportedLayer(it) }
    }

    private fun addImportedLayer(uri: Uri) {
        try {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw Exception("Gambar tidak terbaca")
            val target = Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)
            val c = Canvas(target)
            val scale = min(board.canvasSize.toFloat() / bmp.width, board.canvasSize.toFloat() / bmp.height)
            val w = bmp.width * scale; val h = bmp.height * scale
            val dst = RectF((board.canvasSize-w)/2, (board.canvasSize-h)/2,
                (board.canvasSize+w)/2, (board.canvasSize+h)/2)
            c.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            layers.add(ArtLayer("Imported ${layers.size}", target))
            selectedLayer = layers.lastIndex
            board.setLayers(layers, selectedLayer)
            Toast.makeText(this, "Gambar masuk sebagai layer baru", Toast.LENGTH_SHORT).show()
            refreshStatus()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal import: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportPng() {
        try {
            val merged = Bitmap.createBitmap(board.canvasSize, board.canvasSize, Bitmap.Config.ARGB_8888)
            val c = Canvas(merged)
            layers.filter { it.visible }.forEach { c.drawBitmap(it.bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG)) }
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ARTandPX_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ARTandPX")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Tidak bisa membuat file")
            contentResolver.openOutputStream(uri)?.use { merged.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "PNG tersimpan di Pictures/ARTandPX", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setMessage("Hapus isi layer aktif?")
            .setPositiveButton("Hapus") { _, _ -> board.clearCurrent() }
            .setNegativeButton("Batal", null).show()
    }

    private fun refreshStatus() {
        status.text = "${if (pixelMode) "PIXEL ART" else "NORMAL"} • ${layers.size} layer • ${symmetryName()}"
    }
}

class DrawingBoard(context: android.content.Context, initialLayers: MutableList<ArtLayer>) : View(context) {
    enum class Tool { BRUSH, ERASER, LINE, RECT, OVAL }
    var canvasSize = 1024
        private set
    private var layers = initialLayers
    private var selected = 0
    private var color = Color.BLACK
    private var tool = Tool.BRUSH
    private var pixelMode = false
    private var symmetry = 0
    private var brushSize = 8f
    private var downX = 0f; private var downY = 0f
    private var lastX = 0f; private var lastY = 0f
    private var drawing = false
    private var scale = 1f
    private var offsetX = 0f; private var offsetY = 0f
    private val undo = ArrayDeque<Bitmap>()
    private val redo = ArrayDeque<Bitmap>()
    private var beforeStroke: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = this@DrawingBoard.color; strokeWidth = brushSize
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        style = Paint.Style.STROKE
    }
    private val checkerPaint = Paint().apply { color = Color.rgb(55,56,64) }
    private val bgPaint = Paint().apply { color = Color.rgb(225,225,225) }

    fun setColor(c: Int) { color = c; invalidate() }
    fun setTool(t: Tool) { tool = t }
    fun setPixelMode(enabled: Boolean) {
        // Keep the document resolution unchanged; pixel mode snaps strokes to a coarse grid.
        pixelMode = enabled
        invalidate()
    }
    fun setSymmetry(mode: Int) { symmetry = mode; invalidate() }
    fun setLayers(newLayers: MutableList<ArtLayer>, index: Int) {
        layers = newLayers; selected = index.coerceIn(0, layers.lastIndex); invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val side = min(width, height) * 0.92f
        val left = (width-side)/2f; val top = (height-side)/2f
        val save = canvas.save()
        canvas.translate(left + offsetX, top + offsetY)
        canvas.scale(scale * side / canvasSize, scale * side / canvasSize)
        canvas.drawRect(0f, 0f, canvasSize.toFloat(), canvasSize.toFloat(), bgPaint)
        val cell = if (pixelMode) 8 else 32
        for (y in 0 until canvasSize step cell) for (x in 0 until canvasSize step cell) {
            if (((x/cell)+(y/cell)) % 2 == 0) canvas.drawRect(x.toFloat(), y.toFloat(),
                (x+cell).toFloat(), (y+cell).toFloat(), checkerPaint)
        }
        layers.filter { it.visible }.forEach { canvas.drawBitmap(it.bitmap, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG)) }
        canvas.restoreToCount(save)
    }

    private fun toCanvas(x: Float, y: Float): PointF {
        val side = min(width, height) * 0.92f
        val left = (width-side)/2f + offsetX
        val top = (height-side)/2f + offsetY
        val factor = scale * side / canvasSize
        return PointF(((x-left)/factor).coerceIn(0f, canvasSize.toFloat()),
            ((y-top)/factor).coerceIn(0f, canvasSize.toFloat()))
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val p = toCanvas(event.x, event.y)
                downX = p.x; downY = p.y; lastX = p.x; lastY = p.y
                drawing = true
                val layer = layers.getOrNull(selected) ?: return true
                if (layer.locked) { drawing = false; return true }
                beforeStroke = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true)
                return true
            }
            MotionEvent.ACTION_MOVE -> if (drawing) {
                val p = toCanvas(event.x, event.y)
                if (tool == Tool.BRUSH || tool == Tool.ERASER) {
                    drawSegment(lastX, lastY, p.x, p.y)
                    lastX = p.x; lastY = p.y
                }
                invalidate(); return true
            }
            MotionEvent.ACTION_UP -> if (drawing) {
                val p = toCanvas(event.x, event.y)
                when (tool) {
                    Tool.LINE -> drawShape(downX, downY, p.x, p.y, Tool.LINE)
                    Tool.RECT -> drawShape(downX, downY, p.x, p.y, Tool.RECT)
                    Tool.OVAL -> drawShape(downX, downY, p.x, p.y, Tool.OVAL)
                    else -> if (downX == p.x && downY == p.y) drawSegment(downX, downY, p.x+0.1f, p.y+0.1f)
                }
                beforeStroke?.let { undo.addLast(it); while (undo.size > 20) undo.removeFirst() }
                redo.clear()
                beforeStroke = null; drawing = false; invalidate(); return true
            }
        }
        return true
    }

    private fun snap(v: Float): Float = if (pixelMode) (v / 4f).roundToInt() * 4f else v

    private fun drawSegment(x1: Float, y1: Float, x2: Float, y2: Float) {
        val layer = layers.getOrNull(selected) ?: return
        val c = Canvas(layer.bitmap)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (tool == Tool.ERASER) Color.TRANSPARENT else this@DrawingBoard.color
            strokeWidth = if (pixelMode) max(4f, brushSize) else brushSize
            strokeCap = if (pixelMode) Paint.Cap.SQUARE else Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND; style = Paint.Style.STROKE
            xfermode = if (tool == Tool.ERASER) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
        }
        val points = mutableListOf(PointF(x2,y2))
        if (symmetry == 1 || symmetry == 3) points.add(PointF(canvasSize-x2, y2))
        if (symmetry == 2 || symmetry == 3) points.add(PointF(x2, canvasSize-y2))
        if (symmetry == 3) points.add(PointF(canvasSize-x2, canvasSize-y2))
        points.forEach { q ->
            val mirrorStartX = if (q.x == canvasSize-x2) canvasSize-x1 else x1
            val mirrorStartY = if (q.y == canvasSize-y2) canvasSize-y1 else y1
            val a = snap(mirrorStartX); val b = snap(mirrorStartY)
            val d = snap(q.x); val e = snap(q.y)
            c.drawLine(a,b,d,e,p)
        }
    }

    private fun drawShape(x1: Float, y1: Float, x2: Float, y2: Float, shape: Tool) {
        val layer = layers.getOrNull(selected) ?: return
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = this@DrawingBoard.color; strokeWidth = brushSize; style = Paint.Style.STROKE
        }
        val c = Canvas(layer.bitmap)
        fun one(a: Float, b: Float, d: Float, e: Float) {
            val l=min(a,d); val r=max(a,d); val t=min(b,e); val bot=max(b,e)
            when(shape) {
                Tool.LINE -> c.drawLine(a,b,d,e,p)
                Tool.RECT -> c.drawRect(l,t,r,bot,p)
                Tool.OVAL -> c.drawOval(l,t,r,bot,p)
                else -> {}
            }
        }
        one(x1,y1,x2,y2)
        if (symmetry == 1 || symmetry == 3) one(canvasSize-x1,y1,canvasSize-x2,y2)
        if (symmetry == 2 || symmetry == 3) one(x1,canvasSize-y1,x2,canvasSize-y2)
        if (symmetry == 3) one(canvasSize-x1,canvasSize-y1,canvasSize-x2,canvasSize-y2)
    }

    fun undo() {
        if (undo.isEmpty()) return
        val layer = layers[selected]
        redo.addLast(layer.bitmap.copy(Bitmap.Config.ARGB_8888, true))
        val previous = undo.removeLast()
        Canvas(layer.bitmap).drawBitmap(previous, 0f, 0f, Paint())
        invalidate()
    }
    fun redo() {
        if (redo.isEmpty()) return
        val layer = layers[selected]
        undo.addLast(layer.bitmap.copy(Bitmap.Config.ARGB_8888, true))
        val next = redo.removeLast()
        Canvas(layer.bitmap).drawBitmap(next, 0f, 0f, Paint())
        invalidate()
    }
    fun clearCurrent() {
        val layer = layers[selected]
        if (layer.locked) return
        undo.addLast(layer.bitmap.copy(Bitmap.Config.ARGB_8888, true))
        Canvas(layer.bitmap).drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        invalidate()
    }
}
